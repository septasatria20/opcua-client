/* jshint indent: 2 */
module.exports = {
  // ========== NG TGK LABEL R SERIES ================
  TGK_Count: {
    node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.TGK_Count",
    decimal: 1,
    column: "TGK_Count",
  },
  TGK_NG: {
    node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.TGK_NG",
    decimal: 1,
    column: "TGK_NG",
  },
  ng_tgk: {
    cnt_row1: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW1",
      decimal: 1,
      column: "CNT_ROW1",
    },
    cnt_row2: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW2",
      decimal: 1,
      column: "CNT_ROW2",
    },
    cnt_row3: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW3",
      decimal: 1,
      column: "CNT_ROW3",
    },
    cnt_row4: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW4",
      decimal: 1,
      column: "CNT_ROW4",
    },
    cnt_row5: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW5",
      decimal: 1,
      column: "CNT_ROW5",
    },
    cnt_row6: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW6",
      decimal: 1,
      column: "CNT_ROW6",
    },
    cnt_row7: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW7",
      decimal: 1,
      column: "CNT_ROW7",
    },
    cnt_row8: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW8",
      decimal: 1,
      column: "CNT_ROW8",
    },
    cnt_row9: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW9",
      decimal: 1,
      column: "CNT_ROW9",
    },
    cnt_row10: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW10",
      decimal: 1,
      column: "CNT_ROW10",
    },
    cnt_row11: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW11",
      decimal: 1,
      column: "CNT_ROW11",
    },
    cnt_row12: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW12",
      decimal: 1,
      column: "CNT_ROW12",
    },
    cnt_row13: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW13",
      decimal: 1,
      column: "CNT_ROW13",
    },
    cnt_row14: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW14",
      decimal: 1,
      column: "CNT_ROW14",
    },
    cnt_row15: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW15",
      decimal: 1,
      column: "CNT_ROW15",
    },
    cnt_row16: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW16",
      decimal: 1,
      column: "CNT_ROW16",
    },
    cnt_row17: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW17",
      decimal: 1,
      column: "CNT_ROW17",
    },
    cnt_row18: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW18",
      decimal: 1,
      column: "CNT_ROW18",
    },
    cnt_row19: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW19",
      decimal: 1,
      column: "CNT_ROW19",
    },
    cnt_row20: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.CNT_ROW20",
      decimal: 1,
      column: "CNT_ROW20",
    },
    kode1_row1: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row1",
      decimal: 1,
      column: "kode1_row1",
    },
    kode1_row2: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row2",
      decimal: 1,
      column: "kode1_row2",
    },
    kode1_row3: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row3",
      decimal: 1,
      column: "kode1_row3",
    },
    kode1_row4: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row4",
      decimal: 1,
      column: "kode1_row4",
    },
    kode1_row5: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row5",
      decimal: 1,
      column: "kode1_row5",
    },
    kode1_row6: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row6",
      decimal: 1,
      column: "kode1_row6",
    },
    kode1_row7: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row7",
      decimal: 1,
      column: "kode1_row7",
    },
    kode1_row8: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row8",
      decimal: 1,
      column: "kode1_row8",
    },
    kode1_row9: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row9",
      decimal: 1,
      column: "kode1_row9",
    },
    kode1_row10: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row10",
      decimal: 1,
      column: "kode1_row10",
    },
    kode1_row11: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row11",
      decimal: 1,
      column: "kode1_row11",
    },
    kode1_row12: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row12",
      decimal: 1,
      column: "kode1_row12",
    },
    kode1_row13: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row13",
      decimal: 1,
      column: "kode1_row13",
    },
    kode1_row14: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row14",
      decimal: 1,
      column: "kode1_row14",
    },
    kode1_row15: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row15",
      decimal: 1,
      column: "kode1_row15",
    },
    kode1_row16: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row16",
      decimal: 1,
      column: "kode1_row16",
    },
    kode1_row17: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row17",
      decimal: 1,
      column: "kode1_row17",
    },
    kode1_row18: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row18",
      decimal: 1,
      column: "kode1_row18",
    },
    kode1_row19: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row19",
      decimal: 1,
      column: "kode1_row19",
    },
    kode1_row20: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode1_row20",
      decimal: 1,
      column: "kode1_row20",
    },
    kode2_row1: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row1",
      decimal: 1,
      column: "kode2_row1",
    },
    kode2_row2: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row2",
      decimal: 1,
      column: "kode2_row2",
    },
    kode2_row3: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row3",
      decimal: 1,
      column: "kode2_row3",
    },
    kode2_row4: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row4",
      decimal: 1,
      column: "kode2_row4",
    },
    kode2_row5: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row5",
      decimal: 1,
      column: "kode2_row5",
    },
    kode2_row6: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row6",
      decimal: 1,
      column: "kode2_row6",
    },
    kode2_row7: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row7",
      decimal: 1,
      column: "kode2_row7",
    },
    kode2_row8: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row8",
      decimal: 1,
      column: "kode2_row8",
    },
    kode2_row9: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row9",
      decimal: 1,
      column: "kode2_row9",
    },
    kode2_row10: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row10",
      decimal: 1,
      column: "kode2_row10",
    },
    kode2_row11: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row11",
      decimal: 1,
      column: "kode2_row11",
    },
    kode2_row12: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row12",
      decimal: 1,
      column: "kode2_row12",
    },
    kode2_row13: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row13",
      decimal: 1,
      column: "kode2_row13",
    },
    kode2_row14: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row14",
      decimal: 1,
      column: "kode2_row14",
    },
    kode2_row15: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row15",
      decimal: 1,
      column: "kode2_row15",
    },
    kode2_row16: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row16",
      decimal: 1,
      column: "kode2_row16",
    },
    kode2_row17: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row17",
      decimal: 1,
      column: "kode2_row17",
    },
    kode2_row18: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row18",
      decimal: 1,
      column: "kode2_row18",
    },
    kode2_row19: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row19",
      decimal: 1,
      column: "kode2_row19",
    },
    kode2_row20: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode2_row20",
      decimal: 1,
      column: "kode2_row20",
    },
    kode3_row1: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row1",
      decimal: 1,
      column: "kode3_row1",
    },
    kode3_row2: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row2",
      decimal: 1,
      column: "kode3_row2",
    },
    kode3_row3: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row3",
      decimal: 1,
      column: "kode3_row3",
    },
    kode3_row4: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row4",
      decimal: 1,
      column: "kode3_row4",
    },
    kode3_row5: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row5",
      decimal: 1,
      column: "kode3_row5",
    },
    kode3_row6: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row6",
      decimal: 1,
      column: "kode3_row6",
    },
    kode3_row7: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row7",
      decimal: 1,
      column: "kode3_row7",
    },
    kode3_row8: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row8",
      decimal: 1,
      column: "kode3_row8",
    },
    kode3_row9: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row9",
      decimal: 1,
      column: "kode3_row9",
    },
    kode3_row10: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row10",
      decimal: 1,
      column: "kode3_row10",
    },
    kode3_row11: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row11",
      decimal: 1,
      column: "kode3_row11",
    },
    kode3_row12: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row12",
      decimal: 1,
      column: "kode3_row12",
    },
    kode3_row13: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row13",
      decimal: 1,
      column: "kode3_row13",
    },
    kode3_row14: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row14",
      decimal: 1,
      column: "kode3_row14",
    },
    kode3_row15: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row15",
      decimal: 1,
      column: "kode3_row15",
    },
    kode3_row16: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row16",
      decimal: 1,
      column: "kode3_row16",
    },
    kode3_row17: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row17",
      decimal: 1,
      column: "kode3_row17",
    },
    kode3_row18: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row18",
      decimal: 1,
      column: "kode3_row18",
    },
    kode3_row19: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row19",
      decimal: 1,
      column: "kode3_row19",
    },
    kode3_row20: {
      node: "ns=2;s=PLCMitsubishiOC2.LabelRseries.ng_tgk.kode3_row20",
      decimal: 1,
      column: "kode3_row20",
    },
  },

  //------------ppi_ilb_filler
  ppi_ilb_filler: {
    WIAT22: {
      node: 'ns=2;s=PLC_PREP2.PREP21.WIAT22',
      decimal: 1,
      column: 'T22'
    },
    WIAT23: {
      node: 'ns=2;s=PLC_PREP2.PREP21.WIAT23',
      decimal: 1,
      column: 'T23'
    },
    RIA311: {
      node: 'ns=2;s=PLC_PREP2.PREP22.RIA311',
      decimal: 0.001,
      column: 'RIA311',
      threshold: { // Menggunakan standart kedua
        PS: {
          min: 6.27,
          max: 6.67
        },
        IW: {
          min: 3.64,
          max: 4.04
        }
      },
      prealarm: {
        IW: {
          min: 3.70,
          max: 3.98
        },
        PS: {
          min: 5.96,
          max: 6.36
        }
      },
      identity: 'product',
      alarmname: 'PreAlarm Brix Pocari Blender OCI-2',
      linesection: '1',
      url: '/grafana/d/2K6v0bHMz/brix-ilb-2?orgId=1'
    },
    FICA311: {
      node: 'ns=2;s=PLC_PREP2.PREP22.FICA311',
      decimal: 1,
      column: 'FICA311'
    },
    FICA321: {
      node: 'ns=2;s=PLC_PREP2.PREP22.FICA321',
      decimal: 1,
      column: 'FICA321'
    },
    FICA411: {
      node: 'ns=2;s=PLC_PREP2.PREP23.Flow AUHT',
      decimal: 1,
      column: 'FICA411',
      threshold: {
        t350: {
          min: 10772,
          max: 17952
        },
        t500: {
          min: 13566,
          max: 22609
        },
        t900: {
          min: 18006.61,
          max: 30011.01
        },
      },
      prealarm: {
        t350: {
          min: 11500,
          max: 17500
        },
        t500: {
          min: 14000,
          max: 22000
        },
        t900: {
          min: 17500,
          max: 29000
        },
      },
      identity: 'size',
      alarmname: 'PreAlarm CCP Flow AUHT OCI-2',
      linesection: '1',
      url: '/grafana/d/PfM0hxNGz/flow-auht?orgId=1'
    },
    V3207: {
      node: 'ns=2;s=PLC_PREP2.PREP22.V3207',
      decimal: 0.1,
      column: 'V3207'
    },
    TIA412: {
      node: 'ns=2;s=PLC_PREP2.PREP23.TEMP IN AUHT',
      decimal: 0.1,
      column: 'TICA412',
      threshold: {
        min: 108,
        max: 112
      }
    },
    PIA412: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA412',
      decimal: 0.001,
      column: 'PIA412',
      /*
      threshold: {
        t350: {
          min: 0.6,
          max: 0.8
        },
        t500: {
          min: 0.6,
          max: 0.8
        },
        t900: {
          min: 0.6,
          max: 0.8
        },
      }*/
    },
    PIA417: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA417',
      decimal: 0.001,
      column: 'PIA417'
    },
    TIA413: {
      node: 'ns=2;s=PLC_PREP2.PREP23.TEMP OUT AUHT',
      decimal: 0.1,
      column: 'TIA413',
      threshold: {
        PS: {
          min: 108,
          max: 112
        },
        IW: {
          min: 103,
          max: 107
        }
      },
      prealarm: {
        PS: {
          min: 109,
          max: 111
        },
        IW: {
          min: 103.5,
          max: 106.5
        }
      },
      identity: 'product',
      alarmname: 'PreAlarm CCP Temperature AUHT OCI-2',
      linesection: '1',
      url: '/grafana/d/ocE_AbNGk/temp-auht?orgId=1'
    },
    TICA414: {
      node: 'ns=2;s=PLC_PREP2.PREP23.TICA414',
      decimal: 0.1,
      column: 'TICA414',
      /*
      threshold: {
        t350: {
          min: 23,
          max: 27
        },
        t500: {
          min: 23,
          max: 27
        },
        t900: {
          min: 23,
          max: 27
        },
      }*/
    },
    PIA418: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA418',
      decimal: 0.001,
      column: 'PIA418',
      /*
      threshold: {
        t350: {
          min: 0.015,
          max: 0.2
        },
        t500: {
          min: 0.015,
          max: 0.2
        },
        t900: {
          min: 0.015,
          max: 0.2
        },
      }*/
    },
    PS431: {
      node: 'ns=2;s=PLC_PREP2.PREP23.Press Out PSG',
      decimal: 0.001,
      column: 'PS431',
      /*
      threshold: {
        t350: {
          min: 0.2,
          max: 0.5
        },
        t500: {
          min: 0.2,
          max: 0.5
        },
        t900: {
          min: 0.2,
          max: 0.5
        },
      }*/
    },
    PICT43: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PICT43',
      decimal: 0.001,
      column: 'PICT43',
      /*
      threshold: {
        t350: {
          min: 0.1,
          max: 0.19
        },
        t500: {
          min: 0.1,
          max: 0.19
        },
        t900: {
          min: 0.1,
          max: 0.19
        },
      }*/
    },
    PIAT51: {
      node: 'ns=2;s=PLC_PREP2.PREP24.PIAT51',
      decimal: 0.001,
      column: 'PIAT51',
      /*
      threshold: {
        t350: {
          min: 0.03,
          max: 0.06
        },
        t500: {
          min: 0.03,
          max: 0.06
        },
        t900: {
          min: 0.03,
          max: 0.06
        },
      }*/
    },
    TIAT510: {
      node: 'ns=2;s=PLC_PREP2.PREP24.TIA510',
      decimal: 0.1,
      column: 'TIAT510',
      /*
      threshold: {
        t350: {
          min: 23,
          max: 27
        },
        t500: {
          min: 23,
          max: 27
        },
        t900: {
          min: 23,
          max: 27
        },
      }*/
      prealarm: {
        min: 23.2,
        max: 26.8
      },
      alarmname: 'PreAlarm T51 OCI-2',
      linesection: '6',
      url: '/grafana/d/cWcSJxNMz/temp-t51?orgId=1'
    }
  },
  cttn_prod_area_filling: {
    Counter_filling: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Counter_feed_bottle',
      decimal: 1,
      column: 'counter_filling'
    },
    Counter_product: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Counter_product_bottle',
      decimal: 1,
      column: 'Counter_Product'
    },
    Room_RH: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Room_RH',
      decimal: 0.01,
      column: 'Room_RH'
    },
    Room_temperature: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Room_temp',
      decimal: 0.01,
      column: 'Room_temperature'
    },
    Room_pressure: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Room_press',
      decimal: 0.01,
      column: 'Room_pressure'
    },
    Inverter_Exhaust_Fan_TT: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Speed MD13B',
      decimal: 0.01,
      column: 'Inverter_Exhaust_Fan_TT',
      /*
      threshold: {
        min: 10,
        max: 50
      }*/
    },
    Inverter_Exhaust_Filling: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Speed MD14B',
      decimal: 0.01,
      column: 'Inverter_Exhaust_Filling',
      /*
      threshold: {
        min: 10,
        max: 50
      }*/
    },
    Inverter_Exhaust_Cap_Steril: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Speed MD15B',
      decimal: 0.01,
      column: 'Inverter_Exhaust_Cap_Steril',
      /*
      threshold: {
        min: 10,
        max: 50
      }*/
    },
    Pressure_Filling_Chamber: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.PV_DP_AMB_FILLERB',
      decimal: 0.1,
      column: 'Pressure_Filling_Chamber',
      threshold: {
        min: 1
      },
      prealarm: {
        min: 15
      },
      alarmname: 'PreAlarm Pressure Filler Chamber - OCI-2',
      linesection: '6',
      url: '/grafana/d/VfP8AxHGk/press-chamber?orgId=1'
    },
    Pressure_Transfer_Table: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.DP_AMB_TTB',
      decimal: 0.1,
      column: 'Pressure_Transfer_Table',
      threshold: {
        min: 1
      },
      prealarm: {
        min: 1.1
      },
      alarmname: 'PreAlarm Pressure Transfer Table OCI-2',
      linesection: '6',
      url: '/grafana/d/JCakwrNGk/pressure-transfer-table?orgId=1'
    },
    Diff_Press_Fill_TT: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.PV_DP_FILLER_TTB',
      decimal: 0.1,
      column: 'Diff_Press_Fill_TT',
      /*
      threshold: {
        min: 1
      }*/
    },
    Pressure_Cap_Cool: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.DP_CAPCOOL_AMBB',
      decimal: 0.1,
      column: 'Pressure_Cap_Cool',
      threshold: {
        min: 1
      },
      prealarm: {
        min: 1.1
      },
      alarmname: 'Pressure Cap Cooling alert',
      linesection: '6',
      url: '/grafana/d/pvIp4rHMk/cap-cool?orgId=1'
    },
    Pressure_Cap_Steam: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.PV_DP_CAPSTEAM_AMBB',
      decimal: 0.1,
      column: 'Pressure_Cap_Steam',
      threshold: {
        min: 1
      }
    },
    Diff_Press_Cap_Cool_Steam: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.CAP_CAPCOOL_CAPSTEAMB',
      decimal: 0.1,
      column: 'Diff_Press_Cap_Cool_Steam',
      /*
      threshold: {
        min: 1
      }*/
    },
    Volume_Aseptic_tank: {
      node: 'ns=2;s=PLC_PREP2.PREP24.LICAT51',
      decimal: 1,
      column: 'Volume_Aseptic_tank'
    },
    Pressure_Aseptic_tank: {
      node: 'ns=2;s=PLC_PREP2.PREP24.PIAT51',
      decimal: 1,
      column: 'Pressure_Aseptic_tank'
    },
    Temp_T51B: {
      node: 'ns=2;s=PLC_PREP2.PREP24.TIA510',
      decimal: 0.1,
      column: 'Temp_T51B',
      threshold: {
        min: 23,
        max: 27
      }
    },
    Press_Steam: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.PRESS STEAM',
      decimal: 1,
      column: 'Press_Steam',
      threshold: {
        min: 100,
        max: 150
      },
      prealarm: {
        min: 115,
        max: 135
      },
      alarmname: 'PreAlarm Pressure Steam Cap OCI-2',
      linesection: '6',
      url: '/grafana/d/6FNsN9NGk/press-cap-steam?orgId=1'
    },
    TMR04: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.TMR04',
      decimal: 0.1,
      column: 'Press_Steam_TMR04',
      /*
      threshold: {
        min: 60
      }*/
    },
    TMR05: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.TMR05',
      decimal: 0.1,
      column: 'Press_Steam_TMR05',
      /*
      threshold: {
        min: 71
      }*/
    },
    TMR06: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.TMR06',
      decimal: 0.1,
      column: 'Press_Steam_TMR06',
      /*
      threshold: {
        min: 60
      }*/
    },
    TMR07: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.TMR07',
      decimal: 0.1,
      column: 'Temp_Air_Cool_TMR07',
      /*
      threshold: {
        min: 20,
        max: 30
      }*/
    },
    Rotary_Speed: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.FreQ_Cap',
      decimal: 0.01,
      column: 'Rotary_Speed',
      threshold: {
        max: 49.5
      },
      prealarm: {
        max: 48.5
      },
      alarmname: 'PreAlarm Rotary Speed - OCI-2',
      linesection: '6',
      url: '/grafana/d/QyeoF9NMz/rotary-speed?orgId=1'
    },
    Press_Aseptic_Air: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Press_Act_Air',
      decimal: 0.001,
      column: 'Press_Aseptic_Air',
      /*
      threshold: {
        min: 0.1,
        max: 0.6
      }*/
    },
    Press_Water_Sterile: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Press_Act_Water',
      decimal: 0.001,
      column: 'Press_Water_Sterile'
    },
    Press_Water_sterile_Rot_Joint: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Press_Asp_Rot_kpa',
      decimal: 1,
      column: 'Press_Water_sterile_Rot_Joint'     
    },
    Press_Air_Filler: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.AirPress_Inlet_Filler',
      decimal: 0.1,
      column: 'Press_Air_Filler'
    }
  },
  cttn_injeksi2: {
    CycleCounter: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.CycleCounter',
      decimal: 'string',
      column: 'CycleCounter',
    },
    Back_Pressure: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Back_Pressure',
      decimal: 1,
      column: 'Back_Pressure',
    },
    Barrel_Head_Extension_Temperature: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Barrel_Head_Extension_Temperature',
      decimal: 1,
      column: 'Barrel_Head_Extension_Temperature',
    },
    Barrel_Head_Temperature: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Barrel_Head_Temperature',
      decimal: 1,
      column: 'Barrel_Head_Temperature',
    },
    Cavity_Pressure_At_Transition: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Cavity_Pressure_At_Transition',
      decimal: 1,
      column: 'Cavity_Pressure_At_Transition',
    },
    Cooling_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Cooling_Time',
      decimal: 1,
      column: 'Cooling_Time',
    },
    Coolpik_Horizontal_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Coolpik_Horizontal_Time',
      decimal: 1,
      column: 'Coolpik_Horizontal_Time',
    },
    Coolpik_Vertical_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Coolpik_Vertical_Time',
      decimal: 1,
      column: 'Coolpik_Vertical_Time',
    },
    Cushion: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Cushion',
      decimal: 1,
      column: 'Cushion',
    },
    Cycle_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Cycle_Time',
      decimal: 1,
      column: 'Cycle_Time',
    },
    Distributor_Temperature: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Distributor_Temperature',
      decimal: 1,
      column: 'Distributor_Temperature',
    },
    Effective_Cooling_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Effective_Cooling_Time',
      decimal: 1,
      column: 'Effective_Cooling_Time',
    },
    Ejector_Back_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Ejector_Back_Time',
      decimal: 1,
      column: 'Ejector_Back_Time',
    },
    Ejector_Forward_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Ejector_Forward_Time',
      decimal: 1,
      column: 'Ejector_Forward_Time',
    },
    Ejector_Maximum_Forward_Position: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Ejector_Maximum_Forward_Position',
      decimal: 1,
      column: 'Ejector_Maximum_Forward_Position',
    },
    Extruder_Temperature_1: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Extruder_Temperature_-_1',
      decimal: 1,
      column: 'Extruder_Temperature_1',
    },
    Extruder_Temperature_2: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Extruder_Temperature_-_2',
      decimal: 1,
      column: 'Extruder_Temperature_2',
    },
    Extruder_Temperature_3: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Extruder_Temperature_-_3',
      decimal: 1,
      column: 'Extruder_Temperature_3',
    },
    Extruder_Temperature_4: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Extruder_Temperature_-_4',
      decimal: 1,
      column: 'Extruder_Temperature_4',
    },
    Extruder_Temperature_5: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Extruder_Temperature_-_5',
      decimal: 1,
      column: 'Extruder_Temperature_5',
    },
    Extruder_Temperature_6: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Extruder_Temperature_-_6',
      decimal: 1,
      column: 'Extruder_Temperature_6',
    },
    Extruder_Temperature_7: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Extruder_Temperature_-_7',
      decimal: 1,
      column: 'Extruder_Temperature_7',
    },
    Fill_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Fill_Time',
      decimal: 1,
      column: 'Fill_Time',
    },
    Hold_Pressure_Zone_1: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_1',
      decimal: 1,
      column: 'Hold_Pressure_Zone_1',
    },
    Hold_Pressure_Zone_2: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_2',
      decimal: 1,
      column: 'Hold_Pressure_Zone_2',
    },
    Hold_Pressure_Zone_3: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_3',
      decimal: 1,
      column: 'Hold_Pressure_Zone_3',
    },
    Hold_Pressure_Zone_4: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_4',
      decimal: 1,
      column: 'Hold_Pressure_Zone_4',
    },
    Hold_Pressure_Zone_5: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_5',
      decimal: 1,
      column: 'Hold_Pressure_Zone_5',
    },
    Hold_Pressure_Zone_6: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_6',
      decimal: 1,
      column: 'Hold_Pressure_Zone_6',
    },
    Hold_Pressure_Zone_7: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_7',
      decimal: 1,
      column: 'Hold_Pressure_Zone_7',
    },
    Hold_Pressure_Zone_8: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_8',
      decimal: 1,
      column: 'Hold_Pressure_Zone_8',
    },
    Hold_Pressure_Zone_9: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_9',
      decimal: 1,
      column: 'Hold_Pressure_Zone_9',
    },
    Hold_Pressure_Zone_10: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Hold_Pressure_Zone_-_10',
      decimal: 1,
      column: 'Hold_Pressure_Zone_10',
    },
    Injection_Hold_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Injection_Hold_Time',
      decimal: 1,
      column: 'Injection_Hold_Time',
    },
    Machine_Cycle_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Machine_Cycle_Time',
      decimal: 1,
      column: 'Machine_Cycle_Time',
    },
    Maximum_Cavity_Pressure: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Maximum_Cavity_Pressure',
      decimal: 1,
      column: 'Maximum_Cavity_Pressure',
    },
    Maximum_Fill_Pressure: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Maximum_Fill_Pressure',
      decimal: 1,
      column: 'Maximum_Fill_Pressure',
    },
    Maximum_Transfer_Pressure: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Maximum_Transfer_Pressure',
      decimal: 1,
      column: 'Maximum_Transfer_Pressure',
    },
    Mold_Closing_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Closing_Time',
      decimal: 1,
      column: 'Mold_Closing_Time',
    },
    Mold_Growth: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Growth',
      decimal: 1,
      column: 'Mold_Growth',
    },
    Mold_Heats_Temperature_1: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_1',
      decimal: 1,
      column: 'Mold_Heats_Temperature_1',
    },
    Mold_Heats_Temperature_2: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_2',
      decimal: 1,
      column: 'Mold_Heats_Temperature_2',
    },
    Mold_Heats_Temperature_3: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_3',
      decimal: 1,
      column: 'Mold_Heats_Temperature_3',
    },
    Mold_Heats_Temperature_4: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_4',
      decimal: 1,
      column: 'Mold_Heats_Temperature_4',
    },
    Mold_Heats_Temperature_5: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_5',
      decimal: 1,
      column: 'Mold_Heats_Temperature_5',
    },
    Mold_Heats_Temperature_6: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_6',
      decimal: 1,
      column: 'Mold_Heats_Temperature_6',
    },
    Mold_Heats_Temperature_7: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_7',
      decimal: 1,
      column: 'Mold_Heats_Temperature_7',
    },
    Mold_Heats_Temperature_8: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_8',
      decimal: 1,
      column: 'Mold_Heats_Temperature_8',
    },
    Mold_Heats_Temperature_9: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_9',
      decimal: 1,
      column: 'Mold_Heats_Temperature_9',
    },
    Mold_Heats_Temperature_10: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_10',
      decimal: 1,
      column: 'Mold_Heats_Temperature_10',
    },
    Mold_Heats_Temperature_11: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_11',
      decimal: 1,
      column: 'Mold_Heats_Temperature_11',
    },
    Mold_Heats_Temperature_12: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_12',
      decimal: 1,
      column: 'Mold_Heats_Temperature_12',
    },
    Mold_Heats_Temperature_13: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_13',
      decimal: 1,
      column: 'Mold_Heats_Temperature_13',
    },
    Mold_Heats_Temperature_14: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_14',
      decimal: 1,
      column: 'Mold_Heats_Temperature_14',
    },
    Mold_Heats_Temperature_15: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_15',
      decimal: 1,
      column: 'Mold_Heats_Temperature_15',
    },
    Mold_Heats_Temperature_16: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_16',
      decimal: 1,
      column: 'Mold_Heats_Temperature_16',
    },
    Mold_Heats_Temperature_17: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_17',
      decimal: 1,
      column: 'Mold_Heats_Temperature_17',
    },
    Mold_Heats_Temperature_18: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_18',
      decimal: 1,
      column: 'Mold_Heats_Temperature_18',
    },
    Mold_Heats_Temperature_19: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_19',
      decimal: 1,
      column: 'Mold_Heats_Temperature_19',
    },
    Mold_Heats_Temperature_20: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_20',
      decimal: 1,
      column: 'Mold_Heats_Temperature_20',
    },
    Mold_Heats_Temperature_21: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_21',
      decimal: 1,
      column: 'Mold_Heats_Temperature_21',
    },
    Mold_Heats_Temperature_22: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_22',
      decimal: 1,
      column: 'Mold_Heats_Temperature_22',
    },
    Mold_Heats_Temperature_23: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_23',
      decimal: 1,
      column: 'Mold_Heats_Temperature_23',
    },
    Mold_Heats_Temperature_24: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_24',
      decimal: 1,
      column: 'Mold_Heats_Temperature_24',
    },
    Mold_Heats_Temperature_25: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_25',
      decimal: 1,
      column: 'Mold_Heats_Temperature_25',
    },
    Mold_Heats_Temperature_26: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_26',
      decimal: 1,
      column: 'Mold_Heats_Temperature_26',
    },
    Mold_Heats_Temperature_27: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Heats_Temperature_-_27',
      decimal: 1,
      column: 'Mold_Heats_Temperature_27',
    },
    Mold_Open_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Open_Time',
      decimal: 1,
      column: 'Mold_Open_Time',
    },
    Mold_Opening_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Mold_Opening_Time',
      decimal: 1,
      column: 'Mold_Opening_Time',
    },
    Nozzle_Adapter_Temperature: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Nozzle_Adapter_Temperature',
      decimal: 1,
      column: 'Nozzle_Adapter_Temperature',
    },
    Oil_Temperature: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Oil_Temperature',
      decimal: 1,
      column: 'Oil_Temperature',
    },
    Operator_Cycle_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Operator_Cycle_Time',
      decimal: 1,
      column: 'Operator_Cycle_Time',
    },
    Part_Drop: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Part_Drop',
      decimal: 1,
      column: 'Part_Drop',
    },
    Resin_Temperature: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Resin_Temperature',
      decimal: 1,
      column: 'Resin_Temperature',
    },
    Screw_RPM: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Screw_RPM',
      decimal: 1,
      column: 'Screw_RPM',
    },
    Screw_Run_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Screw_Run_Time',
      decimal: 1,
      column: 'Screw_Run_Time',
    },
    Shooting_Pot_Temperature_19: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Shooting_Pot_Temperature_-_19',
      decimal: 1,
      column: 'Shooting_Pot_Temperature_19',
    },
    Shooting_Pot_Temperature_20: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Shooting_Pot_Temperature_-_20',
      decimal: 1,
      column: 'Shooting_Pot_Temperature_20',
    },
    Shot_Length: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Shot_Length',
      decimal: 1,
      column: 'Shot_Length',
    },
    Shot_Size: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Shot_Size',
      decimal: 1,
      column: 'Shot_Size',
    },
    Tonnage: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Tonnage',
      decimal: 1,
      column: 'Tonnage',
    },
    Tooling_Plate_In_Stage_1: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Tooling_Plate_-_In_-_Stage_1',
      decimal: 1,
      column: 'Tooling_Plate_In_Stage_1',
    },
    Tooling_Plate_In_Stage_2: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Tooling_Plate_-_In_-_Stage_2',
      decimal: 1,
      column: 'Tooling_Plate_In_Stage_2',
    },
    Tooling_Plate_In_Stage_3: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Tooling_Plate_-_In_-_Stage_3',
      decimal: 1,
      column: 'Tooling_Plate_In_Stage_3',
    },
    Tooling_Plate_In_Stage_4: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Tooling_Plate_-_In_-_Stage_4',
      decimal: 1,
      column: 'Tooling_Plate_In_Stage_4',
    },
    Tooling_Plate_Out_Stage_1: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Tooling_Plate_-_Out_-_Stage_1',
      decimal: 1,
      column: 'Tooling_Plate_Out_Stage_1',
    },
    Tooling_Plate_Out_Stage_2: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Tooling_Plate_-_Out_-_Stage_2',
      decimal: 1,
      column: 'Tooling_Plate_Out_Stage_2',
    },
    Tooling_Plate_Out_Stage_3: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Tooling_Plate_-_Out_-_Stage_3',
      decimal: 1,
      column: 'Tooling_Plate_Out_Stage_3',
    },
    Tooling_Plate_Out_Stage_4: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Tooling_Plate_-_Out_-_Stage_4',
      decimal: 1,
      column: 'Tooling_Plate_Out_Stage_4',
    },
    Transfer_Cushion: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Transfer_Cushion',
      decimal: 1,
      column: 'Transfer_Cushion',
    },
    Transfer_Pressure: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Transfer_Pressure',
      decimal: 1,
      column: 'Transfer_Pressure',
    },
    Transfer_Time: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Transfer_Time',
      decimal: 1,
      column: 'Transfer_Time',
    },
    Transition_Position: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Transition_Position',
      decimal: 1,
      column: 'Transition_Position',
    },
    Transition_Pressure: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Transition_Pressure',
      decimal: 1,
      column: 'Transition_Pressure',
    },
    Clamp_Up_Time: {
      node:'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Clamp_Up_Time',
      decimal: 1,
      column: 'Clamp_Up_Time',
    },
    Clamp_Up_Start_Time: {
      node:'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.ProcessVariables.Clamp_Up_Start_Time',
      decimal: 1,
      column: 'Clamp_Up_Start_Time',
    },
    Injeksi_extend_mode: {
      node: 'ns=2;s=PLCMitsubishiOC2.Kanesho.Injeksi_extend_mode',
      decimal: 'string',
      column: 'Injeksi_extend_mode',
    },
    Status_Kanesho: {
      node: 'ns=2;s=PLCMitsubishiOC2.Kanesho.Status Kanesho',
      decimal: 'string',
      column: 'Status_Kanesho',
    },
    MachineState: {
      node: 'ns=2;s=OPC_Husky.Device1.Husky Machines.OC2.MachineState',
      decimal: 'string',
      column: 'MachineState',
    },
    pressure_ijk2: {
      node: 'ns=2;s=Modbuss-Energy1.Press_inj_oc2.Press',
      decimal: 1,
      column: 'pressure_ijk2'
    },
    temp_ijk2: {
      node: 'ns=2;s=Modbuss-Energy1.Temp_inj_oc2.Temperature',
      decimal: 1,
      column: 'temp_ijk2'
    }
  },
  blow2: {
    Container_unit: {
      node: 'ns=2;s=Blow2.OC2.Container_unit',
      decimal: 1,
      column: 'Container_unit'
    },
    A_Good_Count: {
      node: 'ns=2;s=Blow2.OC2.Good_Count',
      decimal: 1,
      column: 'A_Good_Count'
    },
    A_Reject_count: {
      node: 'ns=2;s=Blow2.OC2.Reject_count',
      decimal: 1,
      column: 'A_Reject_count'
    },
    air_flow_h2o2: {
      node: 'ns=2;s=Blow2.OC2.air_flow_h2o2',
      decimal: 1,
      column: 'air_flow_h2o2'
    },
    air_flow_set_h2o2: {
      node: 'ns=2;s=Blow2.OC2.air_flow_set_h2o2',
      decimal: 1,
      column: 'air_flow_set_h2o2'
    },
    AvgOutRate: {
      node: 'ns=2;s=Blow2.OC2.AvgOutRate',
      decimal: 1,
      column: 'AvgOutRate'
    },
    Chill_Oven_Flow: {
      node: 'ns=2;s=Blow2.OC2.Chill_Oven_Flow',
      decimal: 1,
      column: 'Chill_Oven_Flow'
    },
    Chill_Oven_Temp: {
      node: 'ns=2;s=Blow2.OC2.Chill_Oven_Temp',
      decimal: 1,
      column: 'Chill_Oven_Temp'
    },
    DefectPF: {
      node: 'ns=2;s=Blow2.OC2.DefectPF',
      decimal: 1,
      column: 'DefectPF'
    },
    h2o2_liquid_flow: {
      node: 'ns=2;s=Blow2.OC2.h2o2_liquid_flow',
      decimal: 1,
      column: 'h2o2_liquid_flow'
    },
    h2o2_liquid_setpoint: {
      node: 'ns=2;s=Blow2.OC2.h2o2_liquid_setpoint',
      decimal: 1,
      column: 'h2o2_liquid_setpoint'
    },
    MachineNumber: {
      node: 'ns=2;s=Blow2.OC2.MachineNumber',
      decimal: 1,
      column: 'MachineNumber'
    },
    MobDiffReg1: {
      node: 'ns=2;s=Blow2.OC2.MobDiffReg1',
      decimal: 1,
      column: 'MobDiffReg1'
    },
    MoldBodies_Temp: {
      node: 'ns=2;s=Blow2.OC2.MoldBodies_Temp',
      decimal: 1,
      column: 'MoldBodies_Temp'
    },
    MoldNeckBase_Flow: {
      node: 'ns=2;s=Blow2.OC2.MoldNeckBase_Flow',
      decimal: 1,
      column: 'MoldNeckBase_Flow'
    },
    MoldNeckBase_temp: {
      node: 'ns=2;s=Blow2.OC2.MoldNeckBase_temp',
      decimal: 1,
      column: 'MoldNeckBase_temp'
    },
    MotorIntensity: {
      node: 'ns=2;s=Blow2.OC2.MotorIntensity',
      decimal: 1,
      column: 'MotorIntensity'
    },
    noMold: {
      node: 'ns=2;s=Blow2.OC2.noMold',
      decimal: 1,
      column: 'noMold'
    },
    NoOven: {
      node: 'ns=2;s=Blow2.OC2.NoOven',
      decimal: 1,
      column: 'NoOven'
    },
    noPFarm: {
      node: 'ns=2;s=Blow2.OC2.noPFarm',
      decimal: 1,
      column: 'noPFarm'
    },
    outBotleBlow: {
      node: 'ns=2;s=Blow2.OC2.outBotleBlow',
      decimal: 1,
      column: 'outBotleBlow'
    },
    PFused: {
      node: 'ns=2;s=Blow2.OC2.PFused',
      decimal: 1,
      column: 'PFused'
    },
    Press_40Bar: {
      node: 'ns=2;s=Blow2.OC2.Press_40Bar',
      decimal: 1,
      column: 'Press_40Bar'
      //,
      //prealarm: {
       // min: 27,
       // max: 40
      //},
      //alarmname: 'Pressure 40 Bar alert',
      //linesection: '6',
      //url: '/grafana/d/fin4AbHGz/40-bar?orgId=1'
    },
    Press_Spray_Liquid: {
      node: 'ns=2;s=Blow2.OC2.Press_Spray_Liquid',
      decimal: 1,
      column: 'Press_Spray_Liquid'
    },
    PressFixDiff: {
      node: 'ns=2;s=Blow2.OC2.PressFixDiff',
      decimal: 1,
      column: 'PressFixDiff'
    },
    RegulatorSteam1: {
      node: 'ns=2;s=Blow2.OC2.RegulatorSteam1',
      decimal: 1,
      column: 'RegulatorSteam1'
    },
    RejectPressco: {
      node: 'ns=2;s=Blow2.OC2.RejectPressco',
      decimal: 1,
      column: 'RejectPressco'
    },
    Speed: {
      node: 'ns=2;s=Blow2.OC2.Speed',
      decimal: 1,
      column: 'Speed'
    },
    stop: {
      node: 'ns=2;s=Blow2.OC2.stop',
      decimal: 1,
      column: 'stop'
    },
    stop_cause: {
      node: 'ns=2;s=Blow2.OC2.stop_cause',
      decimal: 1,
      column: 'stop_cause'
    },
    MachineEffBlow: {
      node: 'ns=2;s=Blow2.OC2.MachineEff',
      decimal: 1,
      column: 'MachineEffBlow'
    },
    Press_Spray_Air: {
      node: 'ns=2;s=Blow2.OC2.Press_Spray_Air',
      decimal: 1,
      column: 'Press_Spray_Air'
    },
    DewPoint2: {
      node: 'ns=2;s=Blow2.OC2.Temperature_DewPoint_40B',
      decimal: 1,
      column: 'DewPoint2'
    },
    Temperature_Ex_Hood: {
      node: 'ns=2;s=Blow2.OC2.Temperature_Ex_Hood',
      decimal: 1,
      column: 'Temperature_Ex_Hood'
    },
    Temperature_External: {
      node: 'ns=2;s=Blow2.OC2.Temperature_External',
      decimal: 1,
      column: 'Temperature_External'
    },
    Temperature_DewPoint_40B: {
      node: 'ns=2;s=Blow2.OC2.Temperature_DewPoint_40B',
      decimal: 1,
      column: 'Temperature_DewPoint_40B'
    },
    pressure_inside_bottle_1: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_1',
      decimal: 1,
      column: 'pressure_inside_bottle_1'
    }
  },
   //------------cttn_rejectionoc2
  cttn_rejectionoc2: {
    fill_feed_bottle: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Counter_feed_bottle',
      decimal: 1,
      column: 'fill_feed_bottle'
    },
    fill_operation_bottle: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Counter_Operation_Bottle',
      decimal: 1,
      column: 'fill_operation_bottle'
    },

    fill_product_bottle: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Counter_product_bottle',
      decimal: 1,
      column: 'fill_product_bottle'
    },
    fill_reject_defect: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Counter_Reject_Filling _Defect',
      decimal: 1,
      column: 'fill_reject_defect'
    },
    fill_cap_defect: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Cap_Defect',
      decimal: 1,
      column: 'fill_cap_defect'
    },
    cap_cnt_inlet_bpd: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker.CNT_Inlet_BPD',
      decimal: 1,
      column: 'cap_cnt_inlet_bpd'
    },
    cap_cnt_inlet_cc2: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker.CNT_Inlet_CC2',
      decimal: 1,
      column: 'cap_cnt_inlet_cc2'
    },
    cap_cnt_outlet_bpd: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker.CNT_Outlet_BPD',
      decimal: 1,
      column: 'cap_cnt_outlet_bpd'
    },
    cap_bottle_total_count: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker.Counter_Bottle_Check_Total_Count',
      decimal: 1,
      column: 'cap_bottle_total_count'
    },
    cap_bottle_ng_count: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker.Counter_Bottle_NG_Count',
      decimal: 1,
      column: 'cap_bottle_ng_count'
    },
    cap_capper_total_count: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker.Counter_Capper_Check_Total_Count',
      decimal: 1,
      column: 'cap_capper_total_count'
    },
    cap_capper_ng_count: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker.Counter_Capper_NG_Count',
      decimal: 1,
      column: 'cap_capper_ng_count'
    },
    Fallen_Bottle_CC1: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker.Fallen_Bottle_CC1',
      decimal: 1,
      column: 'Fallen_Bottle_CC1'
    },
    cap_ng_cap_high: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Counter_U_NG',
      decimal: 1,
      column: 'cap_ng_cap_high'
    },
    cap_ng_cap_lower: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Counter_L_NG',
      decimal: 1,
      column: 'cap_ng_cap_lower'
    },
    cb_cv_sampling: {
      node:'ns=2;s=PLCMitsubishiOC2.ConveyorCB.CNT_CV_Sampling',
      decimal: 1,
      column: 'cb_cv_sampling'
    },
    cam_inline_cnt_inlet: {
      node:'ns=2;s=PLCMitsubishiOC2.Cam_Inline.CNT_Inlet_Cam_Inline',
      decimal: 1,
      column: 'cam_inline_cnt_inlet'
    },
    cam_inline_cnt_outlet: {
      node:'ns=2;s=PLCMitsubishiOC2.Cam_Inline.CNT_Outlet_Cam_Inline',
      decimal: 1,
      column: 'cam_inline_cnt_outlet'
    },
    cam_inline_abnormal_ng: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cam_Inline.counter_abnormal_ng',
      decimal: 1,
      column: 'cam_inline_abnormal_ng'
    },
    cam_inline_bottom_ng: {
      node:'ns=2;s=PLCMitsubishiOC2.Cam_Inline.counter_bottom_ng',
      decimal: 1,
      column: 'cam_inline_bottom_ng'
    },
    cam_inline_bridge_ng: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cam_Inline.counter_bridge_ng',
      decimal: 1,
      column: 'cam_inline_bridge_ng'
    },
    cam_inline_solution_ng: {
      node:'ns=2;s=PLCMitsubishiOC2.Cam_Inline.counter_solution_ng',
      decimal: 1,
      column: 'cam_inline_solution_ng'
    },
    cam_inline_total_good_bottle: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cam_Inline.counter_total_good_bottle',
      decimal: 1,
      column: 'cam_inline_total_good_bottle'
    },  
    lblchecker_cnt_inlet_label: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.CNT_Inlet_Label',
      decimal: 1,
      column: 'lblchecker_cnt_inlet_label'
    },
    lblchecker_cnt_outlet_label: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.CNT_Outlet_Label_Checker',
      decimal: 1,
      column: 'lblchecker_cnt_outlet_label'
    },
    lblchecker_cnt_roll_label: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.CNT_Roll_Label',
      decimal: 1,
      column: 'lblchecker_cnt_roll_label'
    },
    lblchecker_ng_deference_level: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_Deference_Level',
      decimal: 1,
      column: 'lblchecker_ng_deference_level'
    },
    lblchecker_ng_ijp_print: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_Ijp_Print',
      decimal: 1,
      column: 'lblchecker_ng_ijp_print'
    },
    lblchecker_ng_label_eyemark: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_Label_Eyemark',
      decimal: 1,
      column: 'lblchecker_ng_label_eyemark'
    },
    lblchecker_ng_label_join: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_Label_Join_Defect',
      decimal: 1,
      column: 'lblchecker_ng_label_join'
    },
    lblchecker_ng_lower_label: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_Lower_Label',
      decimal: 1,
      column: 'lblchecker_ng_lower_label'
    },
    lblchecker_total_ng: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_NG_Count',
      decimal: 1,
      column: 'lblchecker_total_ng'
    },
    lblchecker_ng_no_label: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_No_Label',
      decimal: 1,
      column: 'lblchecker_ng_no_label'
    },
    lblchecker_ng_upper_level: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_Uper_Level',
      decimal: 1,
      column: 'lblchecker_ng_upper_level'
    },
    lblchecker_total_count: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_Total_Count',
      decimal: 1,
      column: 'lblchecker_total_count'
    },
    Counter_NG_labeljoin_detectsensor: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_labeljoin_detectsensor',
      decimal: 1,
      column: 'Counter_NG_labeljoin_detectsensor'
    },
    Counter_NG_label_melipat: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_label_melipat',
      decimal: 1,
      column: 'Counter_NG_label_melipat'
    },
    Counter_NG_label_abnormal: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker.Counter_NG_label_abnormal',
      decimal: 1,
      column: 'Counter_NG_label_abnormal'
    },
    caser_cnt_box: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.CNT_Box_Caser',
      decimal: 1,
      column: 'caser_cnt_box'
    },
    paletizer_total_box: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Count_BOX',
      decimal: 1,
      column: 'paletizer_total_box'
    },
    paletizer_total_pallet: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.count pallet',
      decimal: 1,
      column: 'paletizer_total_pallet'
    },
    bpd_total_count: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.total_amount_inspection',
      decimal: 1,
      column: 'bpd_total_count'
    },
    bpd_total_defect: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Counter_Number_Of_Defective',
      decimal: 1,
      column: 'bpd_total_defect'
    },
    Combine_x83: {
      node:'ns=2;s=PLCMitsubishiOC2.ConveyorCB.C_Combine_x83',
      decimal: 1,
      column: 'Combine_x83'
    },
    Combine_x8a: {
      node:'ns=2;s=PLCMitsubishiOC2.ConveyorCB.C_Combine_x8a',
      decimal: 1,
      column: 'Combine_x8a'
    },
    Combine_x101: {
      node:'ns=2;s=PLCMitsubishiOC2.ConveyorCB.C_Combine_x101',
      decimal: 1,
      column: 'Combine_x101'
    },
    Status_Conveyor: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Status Conveyor',
      decimal: 'string',
      column: 'Status_Conveyor',
    },
    Status_Label: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Status Label',
      decimal: 'string',
      column: 'Status_Label',
    },
    Status_Xray: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Status Xray',
      decimal: 'string',
      column: 'Status_Xray',
    },
    reject_X_ray: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.reject X-ray',
      decimal: 1,
      column: 'reject_X_ray',
    },
    c_alu_x11b: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.C_Alu_X11B',
      decimal: 1,
      column: 'c_alu_x11b',
    }
  },
  label_oci2: {
    Label_Length_AVE: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Label_Length_AVE',
      decimal: 1,
      column: 'Label_Length_AVE'
    },
    Label_Length_PV: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Label_Length_PV',
      decimal: 1,
      column: 'Label_Length_PV'
    },
    Label_Length_SV: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Label_Length_SV',
      decimal: 1,
      column: 'Label_Length_SV'
    },
    Temp_G_Roller_Body_PV: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_G_Roller_Body_PV',
      decimal: 1,
      column: 'Temp_G_Roller_Body_PV'
    },
    Temp_Glue_Bar_PV: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_Glue_Bar_PV',
      decimal: 1,
      column: 'Temp_Glue_Bar_PV'
    },
    Temp_Glue_PV: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_Glue_PV',
      decimal: 1,
      column: 'Temp_Glue_PV',
    },
    Temp_Glue_Scrapper_PV: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_Glue_Scrapper_PV',
      decimal: 1,
      column: 'Temp_Glue_Scrapper_PV'
    },
    Temp_Glue_Tank_PV: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_Glue_tank_PV',
      decimal: 1,
      column: 'Temp_Glue_Tank_PV',
    },
    Temp_Glue_Roller_PV: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_glue_roller_PV',
      decimal: 1,
      column: 'Temp_Glue_Roller_PV',
    },
    Speed_Label: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Speed_label',
      decimal: 1,
      column: 'Speed_Label',
    },
    bpd_Lower_pressure_Min: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Lower_pressure_Min',
      decimal: 1,
      column: 'bpd_Lower_pressure_Min',
    },
    bpd_Upper_pressure_Max: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Upper_pressure_Max',
      decimal: 1,
      column: 'bpd_Upper_pressure_Max',
    },
    Temp_G_Roller_Body_SP: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_G_Roller_Body_SP',
      decimal: 1,
      column: 'Temp_G_Roller_Body_SP',
    },
    Temp_Glue_Bar_SP: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_Glue_Bar_SP',
      decimal: 1,
      column: 'Temp_Glue_Bar_SP',
    },
    Temp_Glue_SP: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_Glue_SP',
      decimal: 1,
      column: 'Temp_Glue_SP',
    },
    Temp_Glue_Scrapper_SP: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_Glue_Scrapper_SP',
      decimal: 1,
      column: 'Temp_Glue_Scrapper_SP',
    },
    Temp_Glue_Tank_SP: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_Glue_Tank_SP',
      decimal: 1,
      column: 'Temp_Glue_Tank_SP',
    },
    Temp_Glue_Roller_SP: {
      node: 'ns=2;s=UA_LabelOC2.Label.Mitsubishi Q00UJ/QnU/QnUD/QnUDH/QnUDEH/L.Tags.Temp_Glue_Roller_SP',
      decimal: 1,
      column: 'Temp_Glue_Roller_SP',
    },
    flow_energy: {
      node: 'ns=2;s=UA_Flow_label_OC2.Device1.ProcessData.Energy',
      decimal: 1,
      column: 'flow_energy'
    },
    flow_velocity: {
      node: 'ns=2;s=UA_Flow_label_OC2.Device1.ProcessData.FlowVelocity',
      decimal: 1,
      column: 'flow_velocity'
    },
    flow_mass: {
      node: 'ns=2;s=UA_Flow_label_OC2.Device1.ProcessData.Mass',
      decimal: 1,
      column: 'flow_mass'
    },
    flow_mass_flow_rate: {
      node: 'ns=2;s=UA_Flow_label_OC2.Device1.ProcessData.MassFlowRate',
      decimal: 1,
      column: 'flow_mass_flow_rate'
    },
    flow_pressure: {
      node: 'ns=2;s=UA_Flow_label_OC2.Device1.ProcessData.Pressure',
      decimal: 1,
      column: 'flow_pressure'
    },
    flow_temp: {
      node: 'ns=2;s=UA_Flow_label_OC2.Device1.ProcessData.Temperature',
      decimal: 1,
      column: 'flow_temp'
    },
    flow_volume: {
      node: 'ns=2;s=UA_Flow_label_OC2.Device1.ProcessData.Volume',
      decimal: 1,
      column: 'flow_volume'
    },
    flow_volumetric_flowrate: {
      node: 'ns=2;s=UA_Flow_label_OC2.Device1.ProcessData.VolumetricFlowRate',
      decimal: 1,
      column: 'flow_volumetric_flowrate'
    },
    ijp_ambient_temp: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_ambient_temp',
      decimal: 1,
      column: 'ijp_ambient_temp'
    },
    ijp_cumulative_optime: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_cumulative_optime',
      decimal: 1,
      column: 'ijp_cumulative_optime'
    },
    ijp_deflection_voltage: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_deflection_voltage',
      decimal: 1,
      column: 'ijp_deflection_voltage'
    },
    ijp_excitation_freq: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_excitation_freq',
      decimal: 1,
      column: 'ijp_excitation_freq'
    },
    ijp_excitation_vref: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_excitation_vref',
      decimal: 1,
      column: 'ijp_excitation_vref'
    },
    ijp_ink_alarmtime: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_ink_alarmtime',
      decimal: 1,
      column: 'ijp_ink_alarmtime'
    },
    ijp_ink_makeup: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_ink_makeup',
      decimal: 1,
      column: 'ijp_ink_makeup'
    },
    ink_operating_time: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_ink_operating_time',
      decimal: 1,
      column: 'ink_operating_time'
    },
    ijp_ink_pressure: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_ink_pressure',
      decimal: 1,
      column: 'ijp_ink_pressure'
    },
    ijp_ink_remaining: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_ink_remaining',
      decimal: 1,
      column: 'ijp_ink_remaining'
    },
    ijp_ink_viscosity: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_ink_viscosity',
      decimal: 1,
      column: 'ijp_ink_viscosity'
    },
    ijp_makeup_remaining: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_makeup_remaining',
      decimal: 1,
      column: 'ijp_makeup_remaining'
    },
    ijp_print_count: {
      node: 'ns=2;s=Modbuss-Energy1.Ijp_oc2.ijp_print_count',
      decimal: 1,
      column: 'ijp_print_count'
    }
  },
  filler_add2: {
    Pressure_before_Fi513: {
      node: 'ns=2;s=PLC_PREP2.PREP24.Pressure_before_Fi513',
      decimal: 0.001,
      column: 'Pressure_before_Fi513',
    },
    Pressure_After_Fi513: {
      node: 'ns=2;s=PLC_PREP2.PREP24.Pressure_After_Fi513',
      decimal: 0.001,
      column: 'Pressure_After_Fi513',
    },
    Running_H: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Running_H',
      decimal: 0.01667,
      column: 'Running_H',
    },
    Running_H_AUHT2: {
      node: 'ns=2;s=PLC_PREP2.PREP23.RunningHourAUHT2',
      decimal: 1,
      column: 'Running_H_AUHT2',
    },
    stopper_cap: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Supply_PF_STS',
      decimal: 'string',
      column: 'stopper_cap',
    },
    press_chamber_tandingan: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Press_Chamber_Tandingan',
      decimal: 0.1,
      column: 'press_chamber_tandingan',
    },

    press_cap_tandingan: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Press_Cap_Tandingan',
      decimal: 0.1,
      column: 'press_cap_tandingan',
    },

    bpm: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.BPM_Filler',
      decimal: 1,
      column: 'bpm',
    },

    Vibration_Motor_Cap_Steril: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Vibration_Motor_Cap_Steril',
      decimal: 1,
      column: 'Vibration_Motor_Cap_Steril',
    },

    Vibration_Motor_DischargeCV: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Vibration_Motor_DischargeCV',
      decimal: 1,
      column: 'Vibration_Motor_DischargeCV',
    },
    h2o2_rs: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.h2o2_rs',
      decimal: 'string',
      column: 'h2o2_rs',
    },
    AirPress_Inlet_Filler: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.AirPress_Inlet_Filler',
      decimal: 1,
      column: 'AirPress_Inlet_Filler',
    },
    sip_start_req: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.sip_start_req',
      decimal: 'string',
      column: 'sip_start_req',
    },
    flow_comp: {
      node: 'ns=2;s=ModbusTCP.filler_OC2_flow_air_comp.flow',
      decimal: 1,
      column: 'flow_comp',
    },
    totalizer: {
      node: 'ns=2;s=ModbusTCP.fm_portable.Totalizer',
      decimal: 1,
      column: 'totalizer',
    },
    vibration_main_motor_filler2: {
      node: 'ns=2;s=PLC_PREP2.PREP24.Vibration_Main_motor_filler',
      decimal: 1,
      column: 'vibration_main_motor_filler2',
    },
    flow_air_comp: {
      node: 'ns=2;s=ModbusTCP.filler_OC2_flow_air_comp.flow',
      decimal: 1,
      column: 'flow_air_comp',
    },
    consumsion_total: {
      node: 'ns=2;s=ModbusTCP.filler_OC2_flow_air_comp.consumsion total',
      decimal: 1,
      column: 'consumsion_total',
    },
    cip_op_status: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.csiop proses.cip_op_status',
      decimal: 1,
      column: 'cip_op_status'
    },
    cop_op_status: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.csiop proses.cop_op_status',
      decimal: 1,
      column: 'cop_op_status'
    },
    ffu_op_status: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.csiop proses.ffu_op_status',
      decimal: 1,
      column: 'ffu_op_status'
    },
    hepa_op_status: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.csiop proses.hepa_op_status',
      decimal: 1,
      column: 'hepa_op_status'
    },
    linefilter_op_status: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.csiop proses.linefilter_op_status',
      decimal: 1,
      column: 'linefilter_op_status'
    },
    ln_op_status: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.csiop proses.ln_op_status',
      decimal: 1,
      column: 'ln_op_status'
    },
    sip_op_status: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.csiop proses.sip_op_status',
      decimal: 1,
      column: 'sip_op_status'
    },
    sop_op_status: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.csiop proses.sop_op_status',
      decimal: 1,
      column: 'sop_op_status'
    },
    Current_Exhaust_Fan1: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Exhaust_Fan1',
      decimal: 1,
      column: 'Current_Exhaust_Fan1'
    },
    Current_Exhaust_Fan2: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Exhaust_Fan2',
      decimal: 1,
      column: 'Current_Exhaust_Fan2'
    },
    Current_Exhaust_Fan3: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Exhaust_Fan3',
      decimal: 1,
      column: 'Current_Exhaust_Fan3'
    },
    Current_Hepa_Fan1: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Hepa_Fan1',
      decimal: 1,
      column: 'Current_Hepa_Fan1'
    },
    Current_Hepa_Fan2: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Hepa_Fan2',
      decimal: 1,
      column: 'Current_Hepa_Fan2'
    },
    Current_Motor_Cap_Steril: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Motor_Cap_Steril',
      decimal: 1,
      column: 'Current_Motor_Cap_Steril'
    },
    Current_Motor_Discharge: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Motor_Discharge',
      decimal: 1,
      column: 'Current_Motor_Discharge'
    },
    Current_MainMotor_Filler: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Motor_MainMotor',
      decimal: 1,
      column: 'Current_MainMotor_Filler'
    },
    Current_Recovery_Pump: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Recovery_Pump',
      decimal: 1,
      column: 'Current_Recovery_Pump'
    },
    Current_Up_down: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Current_Up_down',
      decimal: 1,
      column: 'Current_Up_down'
    }
  },
  BPD_OC2: {
    Internal_pressure1: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure1',
      decimal: 1,
      column: 'Internal_pressure1'
    },
    Internal_pressure2: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure2',
      decimal: 1,
      column: 'Internal_pressure2'
    },
    Internal_pressure3: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure3',
      decimal: 1,
      column: 'Internal_pressure3'
    },
    Internal_pressure4: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure4',
      decimal: 1,
      column: 'Internal_pressure4'
    },
    Internal_pressure5: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure5',
      decimal: 1,
      column: 'Internal_pressure5'
    },
    Internal_pressure6: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure6',
      decimal: 1,
      column: 'Internal_pressure6'
    },
    Internal_pressure7: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure7',
      decimal: 1,
      column: 'Internal_pressure7'
    },
    Internal_pressure8: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure8',
      decimal: 1,
      column: 'Internal_pressure8'
    },
    Internal_pressure9: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure9',
      decimal: 1,
      column: 'Internal_pressure9'
    },
    Internal_pressure10: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure10',
      decimal: 1,
      column: 'Internal_pressure10'
    },
    Internal_pressure11: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure11',
      decimal: 1,
      column: 'Internal_pressure11'
    },
    Internal_pressure12: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure12',
      decimal: 1,
      column: 'Internal_pressure12'
    },
    Internal_pressure13: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure13',
      decimal: 1,
      column: 'Internal_pressure13'
    },
    Internal_pressure14: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure14',
      decimal: 1,
      column: 'Internal_pressure14'
    },
    Internal_pressure15: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure15',
      decimal: 1,
      column: 'Internal_pressure15'
    },
    Internal_pressure16: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure16',
      decimal: 1,
      column: 'Internal_pressure16'
    },
    Internal_pressure17: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure17',
      decimal: 1,
      column: 'Internal_pressure17'
    },
    Internal_pressure18: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure18',
      decimal: 1,
      column: 'Internal_pressure18'
    },
    Internal_pressure19: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure19',
      decimal: 1,
      column: 'Internal_pressure19'
    },
    Internal_pressure20: {
      node: 'ns=2;s=PLCKeyence.BPD_OC2.Internal_pressure20',
      decimal: 1,
      column: 'Internal_pressure20'
    },
  },
  prep_add2: {
    C1T_STEP: {
      node: 'ns=2;s=PLC_PREP2.PREP21.C1T_STEP',
      decimal: 1,
      column: 'C1T_STEP'
    },
    C2T_STEP: {
      node: 'ns=2;s=PLC_PREP2.PREP21.C2T_STEP',
      decimal:1,
      column: 'C2T_STEP'
    },
    WIAT21: {
      node: 'ns=2;s=PLC_PREP2.PREP21.WIAT21',
      decimal: 1,
      column: 'WIAT21'
    },
    WIAT22: {
      node: 'ns=2;s=PLC_PREP2.PREP21.WIAT22',
      decimal: 1,
      column: 'WIAT22'
    },
    WIAT23: {
      node: 'ns=2;s=PLC_PREP2.PREP21.WIAT23',
      decimal: 1,
      column: 'WIAT23'
    },
    LT11: {
      node: 'ns=2;s=PLC_PREP2.PREP21.T11',
      decimal: 1,
      column: 'LT11'
    },
    LIA_T13: {
      node: 'ns=2;s=PLC_PREP2.PREP21.LEVEL T13',
      decimal: 1,
      column: 'LIA_T13'
    },
    LICAT31: {
      node: 'ns=2;s=PLC_PREP2.PREP22.LICAT31',
      decimal: 1,
      column: 'LICAT31'
    },
    LICAT31mm: {
      node: 'ns=2;s=PLC_PREP2.PREP22.LICAT31mm',
      decimal: 1,
      column: 'LICAT31mm'
    },
    LICAT32: {
      node: 'ns=2;s=PLC_PREP2.PREP22.LICAT32',
      decimal: 1,
      column: 'LICAT32'
    },
    LICAT32mm: {
      node: 'ns=2;s=PLC_PREP2.PREP22.LICAT32mm',
      decimal: 1,
      column: 'LICAT32mm'
    },
    LICAT33: {
      node: 'ns=2;s=PLC_PREP2.PREP22.LICAT33',
      decimal: 1,
      column: 'LICAT33'
    },
    LICAT33mm: {
      node: 'ns=2;s=PLC_PREP2.PREP22.LICAT33mm',
      decimal: 1,
      column: 'LICAT33mm'
    },
    LIAT411: {
      node: 'ns=2;s=PLC_PREP2.PREP23.LIAT411',
      decimal: 1,
      column: 'LIAT411'
    },
    LVL_T43: {
      node: 'ns=2;s=PLC_PREP2.PREP23.LEVEL TANK T43',
      decimal: 1,
      column: 'LVL_T43'
    },
    LICA_T51: {
      node: 'ns=2;s=PLC_PREP2.PREP24.LICAT51',
      decimal: 1,
      column: 'LICA_T51'
    },
    v_3207: {
      node: 'ns=2;s=PLC_PREP2.PREP22.V3207',
      decimal: 1,
      column: 'v_3207'
    },
    ps432: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PS432',
      decimal: 1,
      column: 'ps432'
    },
    ps511: {
      node: 'ns=2;s=PLC_PREP2.PREP24.PS511',
      decimal: 1,
      column: 'ps511'
    },
    PIA411: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA411',
      decimal: 1,
      column: 'PIA411'
    },
    PIA412: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA412',
      decimal: 1,
      column: 'PIA412'
    },
    PIA413: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA413',
      decimal: 1,
      column: 'PIA413'
    },
    PIA414: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA414',
      decimal: 1,
      column: 'PIA414'
    },
    PIA415: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA415',
      decimal: 1,
      column: 'PIA415'
    },
    PIA416: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA416',
      decimal: 1,
      column: 'PIA416'
    },
    PIA417: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA417',
      decimal: 1,
      column: 'PIA417'
    },
    PIA418: {
      node: 'ns=2;s=PLC_PREP2.PREP23.PIA418',
      decimal: 1,
      column: 'PIA418'
    },
    TIAT21: {
      node:'ns=2;s=PLC_PREP2.PREP21.TIAT21',
      decimal: 1,
      column: 'TIAT21'
    },
  
    TIAT22: {
      node:'ns=2;s=PLC_PREP2.PREP21.TIAT22',
      decimal: 1,
      column: 'TIAT22'
    },

    TIAT23: {
      node: 'ns=2;s=PLC_PREP2.PREP21.TIAT23',
      decimal: 1,
      column: 'TIAT23'
    },
    TIA510: {
      node: 'ns=2;s=PLC_PREP2.PREP24.TIA510',
      decimal: 1,
      column: 'TIA510'
    },
    TIA513: {
      node: 'ns=2;s=PLC_PREP2.PREP24.TIA513',
      decimal: 1,
      column: 'TIA513'
    },
    TIA625: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA625',
      decimal: 1,
      column: 'TIA625'
    },
    TIA626: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA626',
      decimal: 1,
      column: 'TIA626'
    },
    TIA627: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA627',
      decimal: 1,
      column: 'TIA627'
    },
    CIPSTEP: {
      node: 'ns=2;s=PLC_PREP2.PREP25.CIPSTEP',
      decimal: 1,
      column: 'CIPSTEP',
    },
    CIAC1A: {
      node:'ns=2;s=PLC_PREP2.PREP25.CIAC1A',
      decimal: 1,
      column: 'CIAC1A'
    },
    CIACT110: {
      node:'ns=2;s=PLC_PREP2.PREP25.CIACT110B',
      decimal: 1,
      column: 'CIACT110'
    },
    FIAC1A: {
      node:'ns=2;s=PLC_PREP2.PREP25.FIAC1A',
      decimal: 1,
      column: 'FIAC1A'
    },
    LIACT110: {
      node:'ns=2;s=PLC_PREP2.PREP25.LIACT110',
      decimal: 1,
      column: 'LIACT110'
    },
    TIA_C1A: {
      node: 'ns=2;s=PLC_PREP2.PREP25.TIA C1A',
      decimal: 1,
      column: 'TIA_C1A',
    },
    TICC1A: {
      node:'ns=2;s=PLC_PREP2.PREP25.TICC1A',
      decimal: 1,
      column: 'TICC1A'
    },
    CSOP_STEP: {
      node:'ns=2;s=PLC_PREP2.PREP26.C/SOP_STEP',
      decimal: 1,
      column: 'CSOP_STEP'
    },
    CIA611: {
      node:'ns=2;s=PLC_PREP2.PREP26.CIA611',
      decimal: 1,
      column: 'CIA611'
    },

    CIA611_ppm: {
      node: 'ns=2;s=PLC_PREP2.PREP26.CIA611_ppm',
      decimal: 1,
      column: 'CIA611_ppm',
    },
    FIA612: {
      node:'ns=2;s=PLC_PREP2.PREP26.FIA612',
      decimal: 1,
      column: 'FIA612'
    },
    FIA613: {
      node:'ns=2;s=PLC_PREP2.PREP26.FIA613',
      decimal: 1,
      column: 'FIA613'
    },
    LIAT61: {
      node:'ns=2;s=PLC_PREP2.PREP26.LIAT61',
      decimal: 1,
      column: 'LIAT61'
    },
    LIAT62: {
      node: 'ns=2;s=PLC_PREP2.PREP26.LIAT62',
      decimal: 1,
      column: 'LIAT62',
    },
    TIA615: {
      node:'ns=2;s=PLC_PREP2.PREP26.TIA615',
      decimal: 1,
      column: 'TIA615'
    },
    TICA614: {
      node:'ns=2;s=PLC_PREP2.PREP26.TICA614',
      decimal: 1,
      column: 'TICA614'
    },
    Temp_T22_OC2: {
      node:'ns=2;s=PLC_PREP1.PREP1.Temp_T22_OC2',
      decimal: 1,
      column: 'Temp_T22_OC2'
    },
    Temp_T23_OC2: {
      node:'ns=2;s=PLC_PREP1.PREP1.Temp_T23_OC2',
      decimal: 1,
      column: 'Temp_T23_OC2'
    },
    STEP_COP: {
      node:'ns=2;s=PLC_PREP2.PREP26.STEP_COP',
      decimal: 1,
      column: 'STEP_COP'
    },
    STEP_SIP: {
      node:'ns=2;s=PLC_PREP2.PREP26.STEP_SIP',
      decimal: 1,
      column: 'STEP_SIP'
    },
    STEP_AUHT: {
      node:'ns=2;s=PLC_PREP2.PREP23.STEP_AUHT',
      decimal: 1,
      column: 'STEP_AUHT'
    },
    RIA311: {
      node: 'ns=2;s=PLC_PREP2.PREP22.RIA311',
      decimal: 0.001,
      column: 'RIA311'
    },
    TIA_431B: {
      node:'ns=2;s=PLC_PREP2.PREP23.TIA431',
      decimal: 1,
      column: 'TIA_431B'
    },
    TIA_432B: {
      node:'ns=2;s=PLC_PREP2.PREP23.TIA432',
      decimal: 1,
      column: 'TIA_432B'
    },
    TIA_433B: {
      node:'ns=2;s=PLC_PREP2.PREP23.TIA433',
      decimal: 1,
      column: 'TIA_433B'
    },
    TIA_434B: {
      node:'ns=2;s=PLC_PREP2.PREP23.TIA434',
      decimal: 1,
      column: 'TIA_434B'
    },
    TIA_510B: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA510',
      decimal: 1,
      column: 'TIA_510B'
    },
    TIA_521B: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA521',
      decimal: 1,
      column: 'TIA_521B'
    },
    TIA_522B: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA522',
      decimal: 1,
      column: 'TIA_522B'
    },
    PIA_611B: {
      node:'ns=2;s=PLC_PREP2.PREP26.PIA611',
      decimal: 1,
      column: 'PIA_611B'
    },
    PIA_612B: {
      node:'ns=2;s=PLC_PREP2.PREP26.PIA612',
      decimal: 1,
      column: 'PIA_612B'
    },
    TIA_611B: {
      node:'ns=2;s=PLC_PREP2.PREP26.TIA611',
      decimal: 1,
      column: 'TIA_611B'
    },
    TIA_612B: {
      node:'ns=2;s=PLC_PREP2.PREP26.TIA612',
      decimal: 1,
      column: 'TIA_612B'
    },
    PIA_621B: {
      node:'ns=2;s=PLC_PREP2.PREP24.PIA621',
      decimal: 1,
      column: 'PIA_621B'
    },
    PIA_622B: {
      node:'ns=2;s=PLC_PREP2.PREP24.PIA622',
      decimal: 1,
      column: 'PIA_622B'
    },
    PIA_623B: {
      node:'ns=2;s=PLC_PREP2.PREP24.PIA623',
      decimal: 1,
      column: 'PIA_623B'
    },
    PIA_624B: {
      node:'ns=2;s=PLC_PREP2.PREP24.PIA624',
      decimal: 1,
      column: 'PIA_624B'
    },
    PIA_625B: {
      node:'ns=2;s=PLC_PREP2.PREP24.PIA625',
      decimal: 1,
      column: 'PIA_625B'
    },
    PIA_626B: {
      node:'ns=2;s=PLC_PREP2.PREP24.PIA626',
      decimal: 1,
      column: 'PIA_626B'
    },
    TIA_621B: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA621',
      decimal: 1,
      column: 'TIA_621B'
    },
    TIA_622B: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA622',
      decimal: 1,
      column: 'TIA_622B'
    },
    TIA_623B: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA623',
      decimal: 1,
      column: 'TIA_623B'
    },
    TIA_624B: {
      node:'ns=2;s=PLC_PREP2.PREP24.TIA624',
      decimal: 1,
      column: 'TIA_624B'
    }
  },
  prep_add2_mtc_min: {
    Vibration_HWP411B: {
      node: 'ns=2;s=PLC_PREP2.PREP23.Vibration_HWP411B',
      decimal: 1,
      column: 'Vibration_HWP411B'
    },
    Vibration_P411B: {
      node: 'ns=2;s=PLC_PREP2.PREP23.Vibration_P411B',
      decimal: 1,
      column: 'Vibration_P411B'
    },
    Vibration_P412B: {
      node: 'ns=2;s=PLC_PREP2.PREP23.Vibration_P412B',
      decimal: 1,
      column: 'Vibration_P412B'
    },
    Ampere_AT41: {
      node:'ns=2;s=PLC_PREP2.PREP23.Ampere AT41',
      decimal: 1,
      column: 'Ampere_AT41'
    },
    Ampere_HWP_411: {
      node:'ns=2;s=PLC_PREP2.PREP23.Ampere HWP 411',
      decimal: 1,
      column: 'Ampere_HWP_411'
    },
    Ampere_P411: {
      node:'ns=2;s=PLC_PREP2.PREP23.Ampere P411',
      decimal: 1,
      column: 'Ampere_P411'
    },
    Ampere_P412: {
      node:'ns=2;s=PLC_PREP2.PREP23.Ampere P412',
      decimal: 1,
      column: 'Ampere_P412'
    },
    HWP411B_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.HWP411B_TEMP',
      decimal: 1,
      column: 'HWP411B_TEMP',
    },
    HWP411B_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.HWP411B_XAV',
      decimal:1,
      column: 'HWP411B_XAV'
    },
    HWP411B_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.HWP411B_XHFA',
      decimal: 1,
      column: 'HWP411B_XHFA'
    },
    HWP411B_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.HWP411B_ZAV',
      decimal:1,
      column: 'HWP411B_ZAV'
    },
    HWP411B_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.HWP411B_ZHFA',
      decimal: 1,
      column: 'HWP411B_ZHFA'
    },
    P113B_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P113B_TEMP',
      decimal: 1,
      column: 'P113B_TEMP',
    },
    P113B_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P113B_XAV',
      decimal:1,
      column: 'P113B_XAV'
    },
    P113B_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P113B_XHFA',
      decimal: 1,
      column: 'P113B_XHFA'
    },
    P113B_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P113B_ZAV',
      decimal:1,
      column: 'P113B_ZAV'
    },
    P113B_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P113B_ZHFA',
      decimal: 1,
      column: 'P113B_ZHFA'
    },
    P118B_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P118B_TEMP',
      decimal: 1,
      column: 'P118B_TEMP',
    },
    P118B_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P118B_XAV',
      decimal:1,
      column: 'P118B_XAV'
    },
    P118B_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P118B_XHFA',
      decimal: 1,
      column: 'P118B_XHFA'
    },
    P118B_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P118B_ZAV',
      decimal:1,
      column: 'P118B_ZAV'
    },
    P118B_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P118B_ZHFA',
      decimal: 1,
      column: 'P118B_ZHFA'
    },
    P131B_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P131B_TEMP',
      decimal: 1,
      column: 'P131B_TEMP',
    },
    P131B_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P131B_XAV',
      decimal:1,
      column: 'P131B_XAV'
    },
    P131B_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P131B_XHFA',
      decimal: 1,
      column: 'P131B_XHFA'
    },
    P131B_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P131B_ZAV',
      decimal:1,
      column: 'P131B_ZAV'
    },
    P131B_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P131B_ZHFA',
      decimal: 1,
      column: 'P131B_ZHFA'
    },
    P215B_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P215B_TEMP',
      decimal: 1,
      column: 'P215B_TEMP',
    },
    P215B_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P215B_XAV',
      decimal:1,
      column: 'P215B_XAV'
    },
    P215B_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P215B_XHFA',
      decimal: 1,
      column: 'P215B_XHFA'
    },
    P215B_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P215B_ZAV',
      decimal:1,
      column: 'P215B_ZAV'
    },
    P215B_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P215B_ZHFA',
      decimal: 1,
      column: 'P215B_ZHFA'
    },
    P331B_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P331B_TEMP',
      decimal: 1,
      column: 'P331B_TEMP',
    },
    P331B_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P331B_XAV',
      decimal:1,
      column: 'P331B_XAV'
    },
    P331B_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P331B_XHFA',
      decimal: 1,
      column: 'P331B_XHFA'
    },
    P331B_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P331B_ZAV',
      decimal:1,
      column: 'P331B_ZAV'
    },
    P331B_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P331B_ZHFA',
      decimal: 1,
      column: 'P331B_ZHFA'
    },
    P411B_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P411B_TEMP',
      decimal: 1,
      column: 'P411B_TEMP',
    },
    P411B_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P411B_XAV',
      decimal:1,
      column: 'P411B_XAV'
    },
    P411B_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P411B_XHFA',
      decimal: 1,
      column: 'P411B_XHFA'
    },
    P411B_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P411B_ZAV',
      decimal:1,
      column: 'P411B_ZAV'
    },
    P411B_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P411B_ZHFA',
      decimal: 1,
      column: 'P411B_ZHFA'
    },
    P412B_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P412B_TEMP',
      decimal: 1,
      column: 'P412B_TEMP',
    },
    P412B_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P412B_XAV',
      decimal:1,
      column: 'P412B_XAV'
    },
    P412B_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P412B_XHFA',
      decimal: 1,
      column: 'P412B_XHFA'
    },
    P412B_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.P412B_ZAV',
      decimal:1,
      column: 'P412B_ZAV'
    },
    P412B_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.P412B_ZHFA',
      decimal: 1,
      column: 'P412B_ZHFA'
    },
    PSG2_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.PSG2_TEMP',
      decimal: 1,
      column: 'PSG2_TEMP',
    },
    PSG2_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.PSG2_XAV',
      decimal:1,
      column: 'PSG2_XAV'
    },
    PSG2_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.PSG2_XHFA',
      decimal: 1,
      column: 'PSG2_XHFA'
    },
    PSG2_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.PSG2_ZAV',
      decimal:1,
      column: 'PSG2_ZAV'
    },
    PSG2_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.PSG2_ZHFA',
      decimal: 1,
      column: 'PSG2_ZHFA'
    },
    VP131B_TEMP: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.VP131B_TEMP',
      decimal: 1,
      column: 'VP131B_TEMP',
    },
    VP131B_XAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.VP131B_XAV',
      decimal:1,
      column: 'VP131B_XAV'
    },
    VP131B_XHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.VP131B_XHFA',
      decimal: 1,
      column: 'VP131B_XHFA'
    },
    VP131B_ZAV: {
      node: 'ns=2;s=Modbuss-Energy1.TurckVib.VP131B_ZAV',
      decimal:1,
      column: 'VP131B_ZAV'
    },
    VP131B_ZHFA: {
      node:'ns=2;s=Modbuss-Energy1.TurckVib.VP131B_ZHFA',
      decimal: 1,
      column: 'VP131B_ZHFA'
    }
  },
  status_prod: {
    Production: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_Production',
      decimal: 'string',
      column: 'production'
    },
    H2O2: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_H2O2',
      decimal: 'string',
      column: 'h2o2'
    },
    Formalin: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_Formalin',
      decimal: 'string',
      column: 'formalin'
    },
    CSIOP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_CSIOP',
      decimal: 'string',
      column: 'csiop'
    },
    Nightime: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_Nightime',
      decimal: 'string',
      column: 'nighttime'
    }
  },
  history_alarm_capper: {
    cap_no: {
      node: 'ns=2;s=UA_CSI_OC2.CSI.Mitsubishi Q02/02H.Tags.Rej1_No',
      decimal: 1,
      column: 'Rej1_Cap_No'
    },
    day: {
      node: 'ns=2;s=UA_CSI_OC2.CSI.Mitsubishi Q02/02H.Tags.Rej1_Day',
      decimal: 1,
      column: 'Rej1_Day'
    },
    hours: {
      node: 'ns=2;s=UA_CSI_OC2.CSI.Mitsubishi Q02/02H.Tags.Rej1_Hours',
      decimal: 1,
      column: 'Rej1_Hours'
    },
    minute: {
      node: 'ns=2;s=UA_CSI_OC2.CSI.Mitsubishi Q02/02H.Tags.Rej1_Minute',
      decimal: 1,
      column: 'Rej1_Minute'
    },
    month: {
      node: 'ns=2;s=UA_CSI_OC2.CSI.Mitsubishi Q02/02H.Tags.Rej1_month',
      decimal: 1,
      column: 'Rej1_Month'
    },
    reject_code: {
      node: 'ns=2;s=UA_CSI_OC2.CSI.Mitsubishi Q02/02H.Tags.Rej1_Reject_Code',
      decimal: 1,
      column: 'Rej1_Reject_Code'
    }
  },
  pre_alarm2: {
    Mode_350ML: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_350ML',
      decimal: 'string',
      column: 'Mode_350ML'
    },
    Mode_500ML: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_500ML',
      decimal: 'string',
      column: 'Mode_500ML'
    },
    Mode_900ML: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_900ML',
      decimal: 'string',
      column: 'Mode_900ML'
    },
    Mode_CSIOP: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_CSIOP',
      decimal: 'string',
      column: 'Mode_CSIOP'
    },
    Mode_Formalin: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_Formalin',
      decimal: 'string',
      column: 'Mode_Formalin'
    },
    Mode_H2O2: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_H2O2',
      decimal: 'string',
      column: 'Mode_H2O2'
    },
    Mode_Nightime: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_Nightime',
      decimal: 'string',
      column: 'Mode_Nightime'
    },
    Mode_Production: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_Production',
      decimal: 'string',
      column: 'Mode_Production'
    },
    Room_press: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Room_press',
      decimal: 0.01,
      column: 'Room_press'
    },
    rh_ahu_2_1: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.rh_ahu_2_1',
      decimal: 1,
      column: 'rh_ahu_2_1'
    },
    room_pressure: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.room_pressure',
      decimal: 1,
      column: 'room_pressure'
    },
    temp_ahu_2_1: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.temp_ahu_2_1',
      decimal: 1,
      column: 'temp_ahu_2_1'
    },
    Pressure_Filling_Chamber: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.PV_DP_AMB_FILLERB',
      decimal: 0.1,
      column: 'Pressure_Filling_Chamber'
    },
    Pressure_Filling_Chamber_tandingan: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Press_Chamber_Tandingan',
      decimal: 0.1,
      column: 'Pressure_Filling_Chamber_tandingan'
    },
    Pressure_Transfer_Table: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.DP_AMB_TTB',
      decimal: 0.1,
      column: 'Pressure_Transfer_Table'
    },
    Pressure_Cap_Cool: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.DP_CAPCOOL_AMBB',
      decimal: 0.1,
      column: 'Pressure_Cap_Cool'
    },
    Pressure_Cap_Steam: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.PV_DP_CAPSTEAM_AMBB',
      decimal: 0.1,
      column: 'Pressure_Cap_Steam'
    },
    Pressure_Cap_Steam_tandingan: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Press_Cap_Tandingan',
      decimal: 0.1,
      column: 'Pressure_Cap_Steam_tandingan'
    },
    Press_Steam: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.PRESS STEAM',
      decimal: 1,
      column: 'Press_Steam'
    },
    Rotary_Speed: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.FreQ_Cap',
      decimal: 0.01,
      column: 'Rotary_Speed'
    },
    Press_40Bar: {
      node: 'ns=2;s=Blow2.OC2.Press_40Bar',
      decimal: 1,
      column: 'Press_40Bar'
    },  
    h2o2_liquid_flow: {
      node: 'ns=2;s=Blow2.OC2.h2o2_liquid_flow',
      decimal: 1,
      column: 'h2o2_liquid_flow'
    },  
    MobDiffReg1: {
      node: 'ns=2;s=Blow2.OC2.MobDiffReg1',
      decimal: 1,
      column: 'MobDiffReg1'
    },  
    RIA311: {
      node: 'ns=2;s=PLC_PREP2.PREP22.RIA311',
      decimal: 0.001,
      column: 'RIA311'
    },
    FICA411: {
      node: 'ns=2;s=PLC_PREP2.PREP23.Flow AUHT',
      decimal: 1,
      column: 'FICA411'
    },
    TIA413: {
      node: 'ns=2;s=PLC_PREP2.PREP23.TEMP OUT AUHT',
      decimal: 0.1,
      column: 'TIA413'
    },
    PIAT51: {
      node: 'ns=2;s=PLC_PREP2.PREP24.PIAT51',
      decimal: 0.001,
      column: 'PIAT51'
    },
    sts_pf_feeding: {
      node: 'ns=2;s=Blow2.OC2.sts_pf_feeding',
      decimal: 1,
      column: 'sts_pf_feeding'
    },
    Level_Separator: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Level_Separator',
      decimal: 1,
      column: 'Level_Separator'
    },
    status_botol_jatuh_3: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker.status_botol_jatuh_3',
      decimal: 1,
      column: 'status_botol_jatuh_3',
    },
    status_reject5_bpd: {
      node: 'ns=2;s=PLCKeyence.CB2_Transfer_data.status_reject5_bpd',
      decimal: 1,
      column: 'status_reject5_bpd',
    },
    Press_Asp_Rot_kpa: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Press_Asp_Rot_kpa',
      decimal: 1,
      column: 'Press_Asp_Rot_kpa'
    },
    cam_inline_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cam_Inline._System._SecondsInError',
      decimal: 1,
      column: 'cam_inline_sts'
    },
    cap_shorter_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap Shorter._System._SecondsInError',
      decimal: 1,
      column: 'cap_shorter_sts'
    },
    cap_checker_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Cap_Checker._System._SecondsInError',
      decimal: 1,
      column: 'cap_checker_sts'
    },
    caser_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser._System._SecondsInError',
      decimal: 1,
      column: 'caser_sts',
    },
    conveyor_cb_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB._System._SecondsInError',
      decimal: 1,
      column: 'conveyor_cb_sts'
    },
    divider_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider._System._SecondsInError',
      decimal: 1,
      column: 'divider_sts',
    },
    filler_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2._System._SecondsInError',
      decimal: 1,
      column: 'filler_sts',
    },
    kanesho_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Kanesho._System._SecondsInError',
      decimal: 1,
      column: 'kanesho_sts',
    },
    label_checker_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Label_Checker._System._SecondsInError',
      decimal: 1,
      column: 'label_checker_sts'
    },
    labeller_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Labeller._System._SecondsInError',
      decimal: 1,
      column: 'labeller_sts',
    },
    paletizer_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2._System._SecondsInError',
      decimal: 1,
      column: 'paletizer_sts',
    },
    sheet_supplier_sts: {
      node: 'ns=2;s=PLCMitsubishiOC2.Sheet Supplier._System._SecondsInError',
      decimal: 1,
      column: 'sheet_supplier_sts',
    },
    blow2_sts: {
      node: 'ns=2;s=Blow2.OC2._System._SecondsInError',
      decimal: 1,
      column: 'blow2_sts'
    }   
  },
  current_cv_pack2: {
    Mode_350ML: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_350ML',
      decimal: 'string',
      column: 'Mode_350ML'
    },
    Mode_500ML: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_500ML',
      decimal: 'string',
      column: 'Mode_500ML'
    },
    Mode_900ML: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_900ML',
      decimal: 'string',
      column: 'Mode_900ML'
    },
    Mode_CSIOP: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_CSIOP',
      decimal: 'string',
      column: 'Mode_CSIOP'
    },
    Mode_Formalin: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_Formalin',
      decimal: 'string',
      column: 'Mode_Formalin'
    },
    Mode_H2O2: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_H2O2',
      decimal: 'string',
      column: 'Mode_H2O2'
    },
    Mode_Nightime: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_Nightime',
      decimal: 'string',
      column: 'Mode_Nightime'
    },
    Mode_Production: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_Production',
      decimal: 'string',
      column: 'Mode_Production'
    },
    Current_M01: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M01',
      decimal: 0.001,
      column: 'Current_M01'
    },
    Current_MG1: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_MG1',
      decimal: 0.01,
      column: 'Current_MG1'
    },
    Current_MG2: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_MG2',
      decimal: 0.01,
      column: 'Current_MG2'
    },
    Current_M02: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M02',
      decimal: 0.01,
      column: 'Current_M02'
    },
    Current_M03: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M03',
      decimal: 0.01,
      column: 'Current_M03'
    },
    Current_M04: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M04',
      decimal: 0.01,
      column: 'Current_M04'
    },
    Current_M05: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M05',
      decimal: 0.01,
      column: 'Current_M05'
    },
    Current_M06: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M06',
      decimal: 0.01,
      column: 'Current_M06'
    },
    Current_M07: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M07',
      decimal: 0.01,
      column: 'Current_M07'
    },
    Current_M08: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M08',
      decimal: 0.01,
      column: 'Current_M08'
    },  
    Current_M09: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M09',
      decimal: 0.01,
      column: 'Current_M09'
    },  
    Current_M10: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M10',
      decimal: 0.01,
      column: 'Current_M10'
    },  
    Current_M11: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M11',
      decimal: 0.01,
      column: 'Current_M11'
    },
    Current_M12: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M12',
      decimal: 0.01,
      column: 'Current_M12'
    },
    Current_M13: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M13',
      decimal: 0.01,
      column: 'Current_M13'
    },
    Current_M14: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M14',
      decimal: 0.01,
      column: 'Current_M14'
    },
    Current_M15: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M15',
      decimal: 0.01,
      column: 'Current_M15'
    },
    Current_M16: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M16',
      decimal: 0.01,
      column: 'Current_M16'
    },
    Current_M17: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M17',
      decimal: 0.01,
      column: 'Current_M17'
    },
    Current_M18: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M18',
      decimal: 0.01,
      column: 'Current_M18'
    },
    Current_M19: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M19',
      decimal: 0.01,
      column: 'Current_M19'
    },
    Current_M20: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M20',
      decimal: 0.01,
      column: 'Current_M20'
    },
    Current_M20A: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M20A',
      decimal: 0.01,
      column: 'Current_M20A'
    },
    Current_M21: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M21',
      decimal: 0.01,
      column: 'Current_M21',
    },
    Current_M22: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M22',
      decimal: 0.01,
      column: 'Current_M22',
    },
    Current_M23: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M23',
      decimal: 0.01,
      column: 'Current_M23',
    },
    Current_M23A: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M23A',
      decimal: 0.01,
      column: 'Current_M23A',
    },
    Current_M24: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M24',
      decimal: 0.01,
      column: 'Current_M24',
    },
    Current_M25: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M25',
      decimal: 0.01,
      column: 'Current_M25',
    },
    Current_M26: {
    node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M26',
      decimal: 0.01,
      column: 'Current_M26'
    },
    Current_M27: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M27',
      decimal: 0.01,
      column: 'Current_M27',
    },
    Current_M28: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M28',
      decimal: 0.01,
      column: 'Current_M28',
    },
    Current_M29: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M29',
      decimal: 0.01,
      column: 'Current_M29',
    },
    Current_M30: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M30',
      decimal: 0.01,
      column: 'Current_M30'
    },
    Current_M31: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M31',
      decimal: 0.01,
      column: 'Current_M31'
    },
    Current_M32: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M32',
      decimal: 0.01,
      column: 'Current_M32'
    },
    Current_M33: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M33',
      decimal: 0.01,
      column: 'Current_M33'
    },
    Current_M34: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M34',
      decimal: 0.01,
      column: 'Current_M34'
    },
    Current_M41: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M41',
      decimal: 0.01,
      column: 'Current_M41'
    },
    Current_M51: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M51',
      decimal: 0.01,
      column: 'Current_M51'
    },
    Current_M52: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M52',
      decimal: 0.01,
      column: 'Current_M52'
    },
    Current_M53: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M53',
      decimal: 0.01,
      column: 'Current_M53'
    },
    Current_M54: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M54',
      decimal: 0.01,
      column: 'Current_M54'
    },
    Current_M55: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M55',
      decimal: 0.01,
      column: 'Current_M55'
    },
    Current_M56: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M56',
      decimal: 0.01,
      column: 'Current_M56'
    },
    Current_MB1: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_MB1',
      decimal: 0.01,
      column: 'Current_MB1'
    },
    Current_MB2: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_MB2',
      decimal: 0.01,
      column: 'Current_MB2'
    },
    Current_M101: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M101',
      decimal: 0.01,
      column: 'Current_M101'
    },
    Current_M102: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M102',
      decimal: 0.01,
      column: 'Current_M102'
    },
    Current_M103: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M103',
      decimal: 0.01,
      column: 'Current_M103'
    },
    Current_M105: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M105',
      decimal: 0.01,
      column: 'Current_M105'
    },
    Current_M106: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M106',
      decimal: 0.01,
      column: 'Current_M106'
    },
    Current_M107: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M107',
      decimal: 0.01,
      column: 'Current_M107'
    },
    Current_M108: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M108',
      decimal: 0.01,
      column: 'Current_M108'
    },
    Current_M109: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M109',
      decimal: 0.01,
      column: 'Current_M109'
    },
    Current_M110: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M110',
      decimal: 0.01,
      column: 'Current_M110'
    },
    Current_M111: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Current_M111',
      decimal: 0.01,
      column: 'Current_M111'
    },
    Freq_M01: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M01',
      decimal: 0.01,
      column: 'Freq_M01'
    },
    Freq_M02: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M02',
      decimal: 0.01,
      column: 'Freq_M02'
    },
    Freq_M03: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M03',
      decimal: 0.01,
      column: 'Freq_M03'
    },
    Freq_M04: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M04',
      decimal: 0.01,
      column: 'Freq_M04'
    },
    Freq_M05: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M05',
      decimal: 0.01,
      column: 'Freq_M05'
    },
    Freq_M06: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M06',
      decimal: 0.01,
      column: 'Freq_M06'
    },
    Freq_M07: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M07',
      decimal: 0.01,
      column: 'Freq_M07'
    },
    Freq_M08: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M08',
      decimal: 0.01,
      column: 'Freq_M08'
    },
    Freq_M09: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M09',
      decimal: 0.01,
      column: 'Freq_M09'
    },
    Freq_M10: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M10',
      decimal: 0.01,
      column: 'Freq_M10'
    },
    Freq_M101: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M101',
      decimal: 0.01,
      column: 'Freq_M101'
    },
    Freq_M102: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M102',
      decimal: 0.01,
      column: 'Freq_M102'
    },
    Freq_M103: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M103',
      decimal: 0.01,
      column: 'Freq_M103'
    },    
    Freq_M105: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M105',
      decimal: 0.01,
      column: 'Freq_M105'
    },
    Freq_M106: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M106',
      decimal: 0.01,
      column: 'Freq_M106'
    },
    Freq_M107: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M107',
      decimal: 0.01,
      column: 'Freq_M107'
    },
    Freq_M108: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M108',
      decimal: 0.01,
      column: 'Freq_M108'
    },
    Freq_M109: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M109',
      decimal: 0.01,
      column: 'Freq_M109'
    },
    Freq_M11: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M11',
      decimal: 0.01,
      column: 'Freq_M11'
    },
    Freq_M110: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M110',
      decimal: 0.01,
      column: 'Freq_M110'
    },
    Freq_M111: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M111',
      decimal: 0.01,
      column: 'Freq_M111'
    },
    Freq_M12: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M12',
      decimal: 0.01,
      column: 'Freq_M12'
    },
    Freq_M13: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M13',
      decimal: 0.01,
      column: 'Freq_M13'
    },
    Freq_M14: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M14',
      decimal: 0.01,
      column: 'Freq_M14'
    },
    Freq_M15: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M15',
      decimal: 0.01,
      column: 'Freq_M15'
    },
    Freq_M16: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M16',
      decimal: 0.01,
      column: 'Freq_M16'
    },
    Freq_M17: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M17',
      decimal: 0.01,
      column: 'Freq_M17'
    },
    Freq_M18: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M18',
      decimal: 0.01,
      column: 'Freq_M18'
    },
    Freq_M19: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M19',
      decimal: 0.01,
      column: 'Freq_M19'
    },
    Freq_M20: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M20',
      decimal: 0.01,
      column: 'Freq_M20'
    },
    Freq_M21: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M21',
      decimal: 0.01,
      column: 'Freq_M21'
    },
    Freq_M22: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M22',
      decimal: 0.01,
      column: 'Freq_M22'
    },
    Freq_M23: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M23',
      decimal: 0.01,
      column: 'Freq_M23'
    },
    Freq_M24: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M24',
      decimal: 0.01,
      column: 'Freq_M24'
    },
    Freq_M25: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M25',
      decimal: 0.01,
      column: 'Freq_M25'
    },
    Freq_M26: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M26',
      decimal: 0.01,
      column: 'Freq_M26'
    },
    Freq_M27: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M27',
      decimal: 0.01,
      column: 'Freq_M27'
    },
    Freq_M28: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M28',
      decimal: 0.01,
      column: 'Freq_M28'
    },
    Freq_M29: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M29',
      decimal: 0.01,
      column: 'Freq_M29'
    },
    Freq_M30: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M30',
      decimal: 0.01,
      column: 'Freq_M30'
    },
    Freq_M31: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M31',
      decimal: 0.01,
      column: 'Freq_M31'
    },
    Freq_M32: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M32',
      decimal: 0.01,
      column: 'Freq_M32'
    },
    Freq_M33: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M33',
      decimal: 0.01,
      column: 'Freq_M33'
    },
    Freq_M34: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M34',
      decimal: 0.01,
      column: 'Freq_M34'
    },
    Freq_M41: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M41',
      decimal: 0.01,
      column: 'Freq_M41'
    },
    Freq_M51: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M51',
      decimal: 0.01,
      column: 'Freq_M51'
    },
    Freq_M52: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M52',
      decimal: 0.01,
      column: 'Freq_M52'
    },
    Freq_M53: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M53',
      decimal: 0.01,
      column: 'Freq_M53'
    },
    Freq_M54: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M54',
      decimal: 0.01,
      column: 'Freq_M54'
    },
    Freq_M55: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M55',
      decimal: 0.01,
      column: 'Freq_M55'
    },
    Freq_M56: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_M56',
      decimal: 0.01,
      column: 'Freq_M56'
    },
    Freq_MB1: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_MB1',
      decimal: 0.01,
      column: 'Freq_MB1'
    },
    Freq_MB2: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_MB2',
      decimal: 0.01,
      column: 'Freq_MB2'
    },
    Freq_MG1: {
      node: 'ns=2;s=PLCMitsubishiOC2.ConveyorCB.Freq_MG1',
      decimal: 0.01,
      column: 'Freq_MG1'
    }     
  },
  cttn_ln2keyence2: {
    LN_Sensor: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.LN_Sensor',
      decimal: 1,
      column: 'LN_Sensor'
    },
    Temp_Exhaust_BFR_A9: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_Exhaust_BFR_A9',
      decimal: 1,
      column: 'Temp_Exhaust_BFR_A9'
    },
    Temp_Surface_Tank: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_Surface_Tank',
      decimal: 1,
      column: 'Temp_Surface_Tank'
    },
    Temp_Inlet_AFT_A7: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_Inlet_AFT_A7',
      decimal: 1,
      column: 'Temp_Inlet_AFT_A7'
    },
    Level_Separator: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Level_Separator',
      decimal: 1,
      column: 'Level_Separator'
    },
    Pressure_Separator: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Pressure_Separator',
      decimal: 1,
      column: 'Pressure_Separator'
    },
    flow_a1: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.flow_a1',
      decimal: 1,
      column: 'flow_a1'
    },
    flow_a11: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.flow_a11',
      decimal: 1,
      column: 'flow_a11'
    },
    flow_a2: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.flow_a2',
      decimal: 1,
      column: 'flow_a2'
    },
    flow_a4: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.flow_a4',
      decimal: 1,
      column: 'flow_a4'
    },
    flow_a5: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.flow_a5',
      decimal: 1,
      column: 'flow_a5'
    },
    flow_a6: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.flow_a6',
      decimal: 1,
      column: 'flow_a6'
    },
  
  
    Status_A4: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Status_A4',
      decimal: 'string',
      column: 'Status_A4'
    },    
    Status_A5: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Status_A5',
      decimal: 'string',
      column: 'Status_A5'
    },    
    Status_A7: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Status_A7',
      decimal: 'string',
      column: 'Status_A7'
    },    
    Status_Vaccum_Pump: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Status_Vaccum_Pump',
      decimal: 'string',
      column: 'Status_Vaccum_Pump'
    },
    Temp_Exhaust: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_Exhaust',
      decimal: 1,
      column: 'Temp_Exhaust'
    },
    Temp_H1: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_H1',
      decimal: 1,
      column: 'Temp_H1'
    },
    Temp_H2: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_H2',
      decimal: 1,
      column: 'Temp_H2'
    },
    Temp_H3: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_H3',
      decimal: 1,
      column: 'Temp_H3'
    },
    Temp_Mini_Tank: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_Mini_Tank',
      decimal: 1,
      column: 'Temp_Mini_Tank'
    },
    Temp_Nozzle: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_Nozzle',
      decimal: 1,
      column: 'Temp_Nozzle'
    },
    Temp_Nozzle_Filler: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_Nozzle_Filler',
      decimal: 1,
      column: 'Temp_Nozzle_Filler'
    },
    Temp_TH1: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_TH1',
      decimal: 1,
      column: 'Temp_TH1'
    },
    Temp_TH2: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_TH2',
      decimal: 1,
      column: 'Temp_TH2'
    },
    Temp_TH3: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_TH3',
      decimal: 1,
      column: 'Temp_TH3'
    },
    Temp_TH4: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Temp_TH4',
      decimal: 1,
      column: 'Temp_TH4'
    },
    SecondsInError: {
      node: 'ns=2;s=PLCKeyence.LN_OC1._System._SecondsInError',
      decimal: 1,
      column: 'SecondsInError',
    },
    all_shunt_K2: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.all shunt K2',
      decimal: 1,
      column: 'all_shunt_K2',
    },
    speed_K2: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.speed K2',
      decimal: 1,
      column: 'speed_K2',
    },
    Nozzle_position2: {
      node: 'ns=2;s=PLCKeyence.LN_OC2.Nozzle_position',
      decimal: 1,
      column: 'Nozzle_position2',
    }
  },
  blow_add2: {
    Blow_whell_Cab_1_HZ: {
      node:'ns=2;s=Blow2.OC2.Blow_whell_Cab_1_HZ',
      decimal: 1,
      column: 'Blow_whell_Cab_1_HZ'
    },
    Blow_whell_Cab_1_press: {
      node:'ns=2;s=Blow2.OC2.Blow_whell_Cab_1_press',
      decimal: 1,
      column: 'Blow_whell_Cab_1_press'
    },
    Blow_whell_Cab_1_speed: {
      node:'ns=2;s=Blow2.OC2.Blow_whell_Cab_1_speed',
      decimal: 1,
      column: 'Blow_whell_Cab_1_speed'
    },
    Blow_whell_Cab_2_HZ: {
      node: 'ns=2;s=Blow2.OC2.Blow_whell_Cab_2_HZ',
      decimal: 1,
      column: 'Blow_whell_Cab_2_HZ'
    },
    Blow_whell_Cab_2_press: {
      node: 'ns=2;s=Blow2.OC2.Blow_whell_Cab_2_press',
      decimal: 1,
      column: 'Blow_whell_Cab_2_press'
    },
    Blow_whell_Cab_2_speed: {
      node: 'ns=2;s=Blow2.OC2.Blow_whell_Cab_2_speed',
      decimal: 1,
      column: 'Blow_whell_Cab_2_speed',
    },
    Blow_whell_Cab_3_HZ: {
      node: 'ns=2;s=Blow2.OC2.Blow_whell_Cab_3_HZ',
      decimal: 1,
      column: 'Blow_whell_Cab_3_HZ',
    },
    Blow_whell_Cab_3_press: {
      node: 'ns=2;s=Blow2.OC2.Blow_whell_Cab_3_press',
      decimal: 1,
      column: 'Blow_whell_Cab_3_press',
    },
    Blow_whell_Cab_3_speed: {
      node: 'ns=2;s=Blow2.OC2.Blow_whell_Cab_3_speed',
      decimal: 1,
      column: 'Blow_whell_Cab_3_speed',
    },
    Blow_whell_Cab_4_HZ: {
      node: 'ns=2;s=Blow2.OC2.Blow_whell_Cab_4_HZ',
      decimal: 1,
      column: 'Blow_whell_Cab_4_HZ',
    },
    Blow_whell_Cab_4_press: {
      node: 'ns=2;s=Blow2.OC2.Blow_whell_Cab_4_press',
      decimal: 1,
      column: 'Blow_whell_Cab_4_press',
    },
    Blow_whell_Cab_4_speed: {
      node: 'ns=2;s=Blow2.OC2.Blow_whell_Cab_4_speed',
      decimal: 1,
      column: 'Blow_whell_Cab_4_speed',
    },
    Trans_Cab_1_hz: {
      node: 'ns=2;s=Blow2.OC2.Trans_Cab_1_hz',
      decimal: 1,
      column: 'Trans_Cab_1_hz',
    },
    Trans_Cab_1_press: {
      node: 'ns=2;s=Blow2.OC2.Trans_Cab_1_press',
      decimal: 1,
      column: 'Trans_Cab_1_press',
    },
    Trans_Cab_1_speed: {
      node: 'ns=2;s=Blow2.OC2.Trans_Cab_1_speed',
      decimal: 1,
      column: 'Trans_Cab_1_speed',
    },
    Trans_Cab_2_Hz: {
      node: 'ns=2;s=Blow2.OC2.Trans_Cab_2_Hz',
      decimal: 1,
      column: 'Trans_Cab_2_Hz',
    },
    Trans_Cab_2_press: {
      node: 'ns=2;s=Blow2.OC2.Trans_Cab_2_press',
      decimal: 1,
      column: 'Trans_Cab_2_press',
    },
    Trans_Cab_2_speed: {
      node: 'ns=2;s=Blow2.OC2.Trans_Cab_2_speed',
      decimal: 1,
      column: 'Trans_Cab_2_speed',
    },
    flowrate_mold_bodies: {
      node: 'ns=2;s=Blow2.OC2.flowrate_mold_bodies',
      decimal: 1,
      column: 'flowrate_mold_bodies',
    },
    Pressure_Blowing: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Blowing',
      decimal: 1,
      column: 'Pressure_Blowing',
    },
    Good_Count: {
      node:'ns=2;s=Blow2.OC2.Good_Count',
      decimal: 1,
      column: 'Good_Count'
    },
    PFused: {
      node:'ns=2;s=Blow2.OC2.PFused',
      decimal: 1,
      column: 'PFused'
    },

    RejectPressco: {
      node: 'ns=2;s=Blow2.OC2.RejectPressco',
      decimal: 1,
      column: 'RejectPressco',
    },
    
    Reject_count: {
      node:'ns=2;s=Blow2.OC2.Reject_count',
      decimal: 1,
      column: 'Reject_count'
    },
    DefectPF: {
      node:'ns=2;s=Blow2.OC2.DefectPF',
      decimal: 1,
      column: 'DefectPF'
    },
    speed2: {
      node:'ns=2;s=Blow2.OC2.Speed_blow_Bottle_per_Hours',
      decimal: 1,
      column: 'speed2'
    },
    MotorIntensity: {
      node: 'ns=2;s=Blow2.OC2.MotorIntensity',
      decimal: 1,
      column: 'MotorIntensity',
    },
    Temperature_DewPoint_40B: {
      node: 'ns=2;s=Blow2.OC2.Temperature_DewPoint_40B',
      decimal: 1,
      column: 'Temperature_DewPoint_40B',
    },
    Temperature_Ex_Hood: {
      node: 'ns=2;s=Blow2.OC2.Temperature_Ex_Hood',
      decimal: 1,
      column: 'Temperature_Ex_Hood',
    },
    Temperature_External: {
      node: 'ns=2;s=Blow2.OC2.Temperature_External',
      decimal: 1,
      column: 'Temperature_External',
    },
    Temperature_Oven: {
      node: 'ns=2;s=Blow2.OC2.Temperature_Oven',
      decimal: 1,
      column: 'Temperature_Oven',
    },
    Temperature_Preform: {
      node: 'ns=2;s=Blow2.OC2.Temperature_Preform',
      decimal: 1,
      column: 'Temperature_Preform',
    },
    Pressure_Streching: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Streching',
      decimal: 1,
      column: 'Pressure_Streching',
    },
    Pressure_Actuating: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Actuating',
      decimal: 1,
      column: 'Pressure_Actuating',
    },
    dedust_air_pressure: {
      node: 'ns=2;s=Blow2.OC2.dedust_air_pressure',
      decimal: 1,
      column: 'dedust_air_pressure',
    },
    Pressure_preblow: {
      node: 'ns=2;s=Blow2.OC2.Pressure_PreBlowing',
      decimal: 1,
      column: 'Pressure_preblow',
    },
    time_blowing: {
      node: 'ns=2;s=Blow2.OC2.time_blowing',
      decimal: 1,
      column: 'time_blowing',
    },
    time_exhaust: {
      node: 'ns=2;s=Blow2.OC2.time_exhaust',
      decimal: 1,
      column: 'time_exhaust',
    },
    Pressure_Inside_Bottle_1: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_1',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_1',
    },
    Pressure_Inside_Bottle_2: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_2',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_2',
    },
    Pressure_Inside_Bottle_3: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_3',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_3',
    },
    Pressure_Inside_Bottle_4: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_4',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_4',
    },
    Pressure_Inside_Bottle_5: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_5',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_5',
    },
    Pressure_Inside_Bottle_6: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_6',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_6',
    },
    Pressure_Inside_Bottle_7: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_7',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_7',
    },
    Pressure_Inside_Bottle_8: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_8',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_8',
    },
    Pressure_Inside_Bottle_9: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_9',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_9',
    },
    Pressure_Inside_Bottle_10: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_10',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_10',
    },
    Pressure_Inside_Bottle_11: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_11',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_11',
    },
    Pressure_Inside_Bottle_12: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_12',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_12',
    },
    Pressure_Inside_Bottle_13: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_13',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_13',
    },
    Pressure_Inside_Bottle_14: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_14',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_14',
    },
    Pressure_Inside_Bottle_15: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_15',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_15',
    },
    Pressure_Inside_Bottle_16: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_16',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_16',
    },
    Pressure_Inside_Bottle_17: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_17',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_17',
    },
    Pressure_Inside_Bottle_18: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_18',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_18',
    },
    Pressure_Inside_Bottle_19: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_19',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_19',
    },
    Pressure_Inside_Bottle_20: {
      node: 'ns=2;s=Blow2.OC2.Pressure_Inside_Bottle_20',
      decimal: 1,
      column: 'Pressure_Inside_Bottle_20',
    }
  },
  vibration_oci2: {
    Locking_cam_1: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_1',
      decimal: 1,
      column: 'Locking_cam_1'
    },
    Locking_cam_2: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_2',
      decimal: 1,
      column: 'Locking_cam_2'
    },
    Locking_cam_3: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_3',
      decimal: 1,
      column: 'Locking_cam_3'
    },
    Locking_cam_4: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_4',
      decimal: 1,
      column: 'Locking_cam_4'
    },
    Locking_cam_5: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_5',
      decimal: 1,
      column: 'Locking_cam_5'
    },
    Locking_cam_6: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_6',
      decimal: 1,
      column: 'Locking_cam_6'
    },
    Locking_cam_7: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_7',
      decimal: 1,
      column: 'Locking_cam_7'
    },
    Locking_cam_8: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_8',
      decimal: 1,
      column: 'Locking_cam_8'
    },
    Locking_cam_9: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_9',
      decimal: 1,
      column: 'Locking_cam_9'
    },
    Locking_cam_10: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_10',
      decimal: 1,
      column: 'Locking_cam_10'
    },
    Locking_cam_11: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_11',
      decimal: 1,
      column: 'Locking_cam_11'
    },
    Locking_cam_12: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_12',
      decimal: 1,
      column: 'Locking_cam_12'
    },
    Locking_cam_13: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_13',
      decimal: 1,
      column: 'Locking_cam_13'
    },
    Locking_cam_14: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_14',
      decimal: 1,
      column: 'Locking_cam_14'
    },
    Locking_cam_15: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_15',
      decimal: 1,
      column: 'Locking_cam_15'
    },
    Locking_cam_16: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_16',
      decimal: 1,
      column: 'Locking_cam_16'
    },
    Locking_cam_17: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_17',
      decimal: 1,
      column: 'Locking_cam_17'
    },
    Locking_cam_18: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_18',
      decimal: 1,
      column: 'Locking_cam_18'
    },
    Locking_cam_19: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_19',
      decimal: 1,
      column: 'Locking_cam_19'
    },
    Locking_cam_20: {
      node: 'ns=2;s=blow 1 vibration.OC2.Locking_cam_20',
      decimal: 1,
      column: 'Locking_cam_20'
    },
    Open_Closed_cam_1: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_1',
      decimal: 1,
      column: 'Open_Closed_cam_1'
    },
    Open_Closed_cam_2: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_2',
      decimal: 1,
      column: 'Open_Closed_cam_2'
    },
    Open_Closed_cam_3: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_3',
      decimal: 1,
      column: 'Open_Closed_cam_3'
    },
    Open_Closed_cam_4: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_4',
      decimal: 1,
      column: 'Open_Closed_cam_4'
    },
    Open_Closed_cam_5: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_5',
      decimal: 1,
      column: 'Open_Closed_cam_5'
    },
    Open_Closed_cam_6: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_6',
      decimal: 1,
      column: 'Open_Closed_cam_6'
    },
    Open_Closed_cam_7: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_7',
      decimal: 1,
      column: 'Open_Closed_cam_7'
    },
    Open_Closed_cam_8: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_8',
      decimal: 1,
      column: 'Open_Closed_cam_8'
    },
    Open_Closed_cam_9: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_9',
      decimal: 1,
      column: 'Open_Closed_cam_9'
    },
    Open_Closed_cam_10: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_10',
      decimal: 1,
      column: 'Open_Closed_cam_10'
    },
    Open_Closed_cam_11: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_11',
      decimal: 1,
      column: 'Open_Closed_cam_11'
    },
    Open_Closed_cam_12: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_12',
      decimal: 1,
      column: 'Open_Closed_cam_12'
    },
    Open_Closed_cam_13: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_13',
      decimal: 1,
      column: 'Open_Closed_cam_13'
    },
    Open_Closed_cam_14: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_14',
      decimal: 1,
      column: 'Open_Closed_cam_14'
    },
    Open_Closed_cam_15: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_15',
      decimal: 1,
      column: 'Open_Closed_cam_15'
    },
    Open_Closed_cam_16: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_16',
      decimal: 1,
      column: 'Open_Closed_cam_16'
    },
    Open_Closed_cam_17: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_17',
      decimal: 1,
      column: 'Open_Closed_cam_17'
    },
    Open_Closed_cam_18: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_18',
      decimal: 1,
      column: 'Open_Closed_cam_18'
    },
    Open_Closed_cam_19: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_19',
      decimal: 1,
      column: 'Open_Closed_cam_19'
    },
    Open_Closed_cam_20: {
      node: 'ns=2;s=blow 1 vibration.OC2.Open_Closed_cam_20',
      decimal: 1,
      column: 'Open_Closed_cam_20'
    },
    Streching_cam_1: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_1',
      decimal: 1,
      column: 'Streching_cam_1'
    },
    Streching_cam_2: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_2',
      decimal: 1,
      column: 'Streching_cam_2'
    },
    Streching_cam_3: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_3',
      decimal: 1,
      column: 'Streching_cam_3'
    },
    Streching_cam_4: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_4',
      decimal: 1,
      column: 'Streching_cam_4'
    },
    Streching_cam_5: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_5',
      decimal: 1,
      column: 'Streching_cam_5'
    },
    Streching_cam_6: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_6',
      decimal: 1,
      column: 'Streching_cam_6'
    },
    Streching_cam_7: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_7',
      decimal: 1,
      column: 'Streching_cam_7'
    },
    Streching_cam_8: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_8',
      decimal: 1,
      column: 'Streching_cam_8'
    },
    Streching_cam_9: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_9',
      decimal: 1,
      column: 'Streching_cam_9'
    },
    Streching_cam_10: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_10',
      decimal: 1,
      column: 'Streching_cam_10'
    },
    Streching_cam_11: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_11',
      decimal: 1,
      column: 'Streching_cam_11'
    },
    Streching_cam_12: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_12',
      decimal: 1,
      column: 'Streching_cam_12'
    },
    Streching_cam_13: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_13',
      decimal: 1,
      column: 'Streching_cam_13'
    },
    Streching_cam_14: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_14',
      decimal: 1,
      column: 'Streching_cam_14'
    },
    Streching_cam_15: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_15',
      decimal: 1,
      column: 'Streching_cam_15'
    },
    Streching_cam_16: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_16',
      decimal: 1,
      column: 'Streching_cam_16'
    },
    Streching_cam_17: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_17',
      decimal: 1,
      column: 'Streching_cam_17'
    },
    Streching_cam_18: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_18',
      decimal: 1,
      column: 'Streching_cam_18'
    },
    Streching_cam_19: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_19',
      decimal: 1,
      column: 'Streching_cam_19'
    },
    Streching_cam_20: {
      node: 'ns=2;s=blow 1 vibration.OC2.Streching_cam_20',
      decimal: 1,
      column: 'Streching_cam_20'
    },
    UP_Down_cam_1: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_1',
      decimal: 1,
      column: 'UP_Down_cam_1'
    },
    UP_Down_cam_2: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_2',
      decimal: 1,
      column: 'UP_Down_cam_2'
    },
    UP_Down_cam_3: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_3',
      decimal: 1,
      column: 'UP_Down_cam_3'
    },
    UP_Down_cam_4: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_4',
      decimal: 1,
      column: 'UP_Down_cam_4'
    },
    UP_Down_cam_5: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_5',
      decimal: 1,
      column: 'UP_Down_cam_5'
    },
    UP_Down_cam_6: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_6',
      decimal: 1,
      column: 'UP_Down_cam_6'
    },
    UP_Down_cam_7: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_7',
      decimal: 1,
      column: 'UP_Down_cam_7'
    },
    UP_Down_cam_8: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_8',
      decimal: 1,
      column: 'UP_Down_cam_8'
    },
    UP_Down_cam_9: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_9',
      decimal: 1,
      column: 'UP_Down_cam_9'
    },
    UP_Down_cam_10: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_10',
      decimal: 1,
      column: 'UP_Down_cam_10'
    },
    UP_Down_cam_11: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_11',
      decimal: 1,
      column: 'UP_Down_cam_11'
    },
    UP_Down_cam_12: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_12',
      decimal: 1,
      column: 'UP_Down_cam_12'
    },
    UP_Down_cam_13: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_13',
      decimal: 1,
      column: 'UP_Down_cam_13'
    },
    UP_Down_cam_14: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_14',
      decimal: 1,
      column: 'UP_Down_cam_14'
    },
    UP_Down_cam_15: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_15',
      decimal: 1,
      column: 'UP_Down_cam_15'
    },
    UP_Down_cam_16: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_16',
      decimal: 1,
      column: 'UP_Down_cam_16'
    },
    UP_Down_cam_17: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_17',
      decimal: 1,
      column: 'UP_Down_cam_17'
    },
    UP_Down_cam_18: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_18',
      decimal: 1,
      column: 'UP_Down_cam_18'
    },
    UP_Down_cam_19: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_19',
      decimal: 1,
      column: 'UP_Down_cam_19'
    },
    UP_Down_cam_20: {
      node: 'ns=2;s=blow 1 vibration.OC2.UP_Down_cam_20',
      decimal: 1,
      column: 'UP_Down_cam_20'
    },
    speed_blow: {
      node: 'ns=2;s=Blow2.OC2.Speed',
      decimal: 1,
      column: 'speed_blow'
    },
    vib_blow2: {
      node: 'ns=2;s=ModbusTCP.Adv_ibf2.vib_blow2',
      decimal: 1,
      column: 'vib_blow2'
    },
    vib_injection2: {
      node: 'ns=2;s=ModbusTCP.Adv_ibf2.vib_injection2',
      decimal: 1,
      column: 'vib_injection2'
    }
  },
  vibration_oci2_min: {
    MD13_accel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.MD13_accel',
      decimal: 1,
      column: 'MD13_accel'
    },
    MD13_envel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.MD13_envel',
      decimal: 1,
      column: 'MD13_envel'
    },
    MD13_veloc: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.MD13_veloc',
      decimal: 1,
      column: 'MD13_veloc'
    },
    MD14_accel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.MD14_accel',
      decimal: 1,
      column: 'MD14_accel'
    },
    MD14_envel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.MD14_envel',
      decimal: 1,
      column: 'MD14_envel'
    },
    MD14_veloc: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.MD14_veloc',
      decimal: 1,
      column: 'MD14_veloc'
    },
    MD15_accel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.MD15_accel',
      decimal: 1,
      column: 'MD15_accel'
    },
    MD15_envel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.MD15_envel',
      decimal: 1,
      column: 'MD15_envel'
    },
    MD15_veloc: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.MD15_veloc',
      decimal: 1,
      column: 'MD15_veloc'
    },
    RF21_accel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.RF21_accel',
      decimal: 1,
      column: 'RF21_accel'
    },
    RF21_envel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.RF21_envel',
      decimal: 1,
      column: 'RF21_envel'
    },
    RF21_veloc: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.RF21_veloc',
      decimal: 1,
      column: 'RF21_veloc'
    },
    ahu21_accel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.ahu21_accel',
      decimal: 1,
      column: 'ahu21_accel'
    },
    ahu21_envel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.ahu21_envel',
      decimal: 1,
      column: 'ahu21_envel'
    },
    ahu21_veloc: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.ahu21_veloc',
      decimal: 1,
      column: 'ahu21_veloc'
    },
    ahu22_accel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.ahu22_accel',
      decimal: 1,
      column: 'ahu22_accel'
    },
    ahu22_envel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.ahu22_envel',
      decimal: 1,
      column: 'ahu22_envel'
    },
    ahu22_veloc: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.ahu22_veloc',
      decimal: 1,
      column: 'ahu22_veloc'
    },
    oac_a_accel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.oac_a_accel',
      decimal: 1,
      column: 'oac_a_accel'
    },
    oac_a_envel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.oac_a_envel',
      decimal: 1,
      column: 'oac_a_envel'
    },
    oac_a_veloc: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.oac_a_veloc',
      decimal: 1,
      column: 'oac_a_veloc'
    },
    oac_b_accel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.oac_b_accel',
      decimal: 1,
      column: 'oac_b_accel'
    },
    oac_b_envel: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.oac_b_envel',
      decimal: 1,
      column: 'oac_b_envel'
    },
    oac_b_veloc: {
      node: 'ns=2;s=ModbusTCP.vibration_hvac_oc2.oac_b_veloc',
      decimal: 1,
      column: 'oac_b_veloc'
    }
  },
  timer_plc_filler2: {
    Timer_DP_CapAir_AA: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Timer_DP_CapAir_AA',
      decimal: 1,
      column: 'Timer_DP_CapAir_AA',
    },
   Timer_DP_CapSteam_AA: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Timer_DP_CapSteam_AA',
      decimal:1,
      column: 'Timer_DP_CapSteam_AA'
    },
   Timer_DP_FIller_AA: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Timer_DP_FIller_AA',
      decimal: 1,
      column: 'Timer_DP_FIller_AA'
    },
    Timer_DP_TT_AA: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filler2_1.Timer_DP_TT_AA',
      decimal: 1,
      column: 'Timer_DP_TT_AA'
    }
  },
  hvac2: {
    aeration_1_h2o2: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.aeration_1_h2o2',
      decimal: 'string',
      column: 'aeration_1_h2o2'
    },
    aeration_2: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.aeration_2',
      decimal: 'string',
      column: 'aeration_2'
    },
    aeration_2_h2o2: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.aeration_2_h2o2',
      decimal: 'string',
      column: 'aeration_2_h2o2'
    },
    aeration_2_room: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.aeration_2_room',
      decimal: 'string',
      column: 'aeration_2_room'
    },
    allfresh_h2o2: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.allfresh_h2o2',
      decimal: 'string',
      column: 'allfresh_h2o2'
    },
    ch2o_mode: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.ch2o_mode',
      decimal: 'string',
      column: 'ch2o_mode'
    },
    csiop_mode: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.csiop_mode',
      decimal: 'string',
      column: 'csiop_mode'
    },
    h2o2_mode: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.h2o2_mode',
      decimal: 'string',
      column: 'h2o2_mode'
    },
    idle_mode: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.idle_mode',
      decimal: 'string',
      column: 'idle_mode'
    },
    new_h2o2_room: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.new_h2o2_room',
      decimal: 'string',
      column: 'new_h2o2_room'
    },
    normal_mode: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.normal_mode',
      decimal: 'string',
      column: 'normal_mode'
    },
    rh_ahu_2_1: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.rh_ahu_2_1',
      decimal: 1,
      column: 'rh_ahu_2_1'
    },
    room_pressure: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.room_pressure',
      decimal: 1,
      column: 'room_pressure'
    },
    temp_ahu_2_1: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.temp_ahu_2_1',
      decimal: 1,
      column: 'temp_ahu_2_1'
    },
    temp_ahu_2_2: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.temp_ahu_2_2',
      decimal: 1,
      column: 'temp_ahu_2_2'
    },
    temp_oac: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.temp_oac',
      decimal: 1,
      column: 'temp_oac'
    },
    velocity_oac: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.velocity_oac',
      decimal: 1,
      column: 'velocity_oac'
    },
    velosity_ahu_2_1: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.velosity_ahu_2_1',
      decimal: 1,
      column: 'velosity_ahu_2_1'
    },
    velosity_ahu_2_2: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.velosity_ahu_2_2',
      decimal: 1,
      column: 'velosity_ahu_2_2'
    },
    dewpoint_ahu_2_1: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.dewpoint_ahu_2_1',
      decimal: 1,
      column: 'dewpoint_ahu_2_1'
    },
    dewpoint_oas: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.dewpoint_oas',
      decimal: 1,
      column: 'dewpoint_oas'
    },
    eh_ahu_2_1: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.eh_ahu_2_1',
      decimal: 1,
      column: 'eh_ahu_2_1'
    },
    eh_ahu_2_2: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.eh_ahu_2_2',
      decimal: 1,
      column: 'eh_ahu_2_2'
    },
    eh_oac: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.eh_oac',
      decimal: 1,
      column: 'eh_oac'
    },
    humidity_ahu_2_1: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.humidity_ahu_2_1',
      decimal: 1,
      column: 'humidity_ahu_2_1'
    },
    humidity_ahu_2_2: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.humidity_ahu_2_2',
      decimal: 1,
      column: 'humidity_ahu_2_2'
    },
    humidity_oac: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.humidity_oac',
      decimal: 1,
      column: 'humidity_oac'
    },
    mv_ahu_2_1: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.mv_ahu_2_1',
      decimal: 1,
      column: 'mv_ahu_2_1'
    },
    mv_ahu_2_2: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.mv_ahu_2_2',
      decimal: 1,
      column: 'mv_ahu_2_2'
    },
    mv_oac: {
      node: 'ns=2;s=UA_HVAC.oc2.BACnetOC2.Tags.mv_oac',
      decimal: 1,
      column: 'mv_oac'
    }
  },
  presco2: {
    CurrentPart: {
      node:'ns=2;s=UA_Presco_OC2.presco.Lane2.CurrentPart',
      decimal: 'string',
      column: 'CurrentPart'
    },
    AlarmActive: {
      node:'ns=2;s=UA_Presco_OC2.presco.Lane2.AlarmActive',
      decimal: 'string',
      column: 'AlarmActive'
    },
    PartRate: {
      node:'ns=2;s=UA_Presco_OC2.presco.Lane2.PartRate',
      decimal: 1,
      column: 'PartRate'
    },
    TimeLastReset: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.TimeLastReset',
      decimal: 'string',
      column: 'TimeLastReset'
    },
    TotalNumberDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.TotalNumberDefects',
      decimal: 1,
      column: 'TotalNumberDefects'
    },
    TotalNumberInspected: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.TotalNumberInspected',
      decimal: 1,
      column: 'TotalNumberInspected'
    },
    TotalPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.TotalPercentDefects',
      decimal: 1,
      column: 'TotalPercentDefects'
    },
    EncoderFrequency: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.EncoderFrequency',
      decimal: 1,
      column: 'EncoderFrequency'
    },
    Online: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Online',
      decimal: 'string',
      column: 'Online'
    },
    BaseTotalNumberDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Base.TotalNumberDefects',
      decimal: 1,
      column: 'BaseTotalNumberDefects'
    },
    BaseTotalPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Base.TotalPercentDefects',
      decimal: 1,
      column: 'BaseTotalPercentDefects'
    },
    BaseRecentPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Base.RecentPercentDefects',
      decimal: 1,
      column: 'BaseRecentPercentDefects'
    },
    SealTotalNumberDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Seal.TotalNumberDefects',
      decimal: 1,
      column: 'SealTotalNumberDefects'
    },
    SealTotalPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Seal.TotalPercentDefects',
      decimal: 1,
      column: 'SealTotalPercentDefects'
    },
    SealRecentPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Seal.RecentPercentDefects',
      decimal: 1,
      column: 'SealRecentPercentDefects'
    },
    UpBodyTotalNumberDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Upper-Sidewall.TotalNumberDefects',
      decimal: 1,
      column: 'UpBodyTotalNumberDefects'
    },
    UpBodyTotalPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Upper-Sidewall.TotalPercentDefects',
      decimal: 1,
      column: 'UpBodyTotalPercentDefects'
    },
    UpBodyRecentPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Upper-Sidewall.RecentPercentDefects',
      decimal: 1,
      column: 'UpBodyRecentPercentDefects'
    },
    LowBodyTotalNumberDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Lower-Sidewall.TotalNumberDefects',
      decimal: 1,
      column: 'LowBodyTotalNumberDefects'
    },
    LowBodyTotalPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Lower-Sidewall.TotalPercentDefects',
      decimal: 1,
      column: 'LowBodyTotalPercentDefects'
    },
    LowBodyRecentPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.Lower-Sidewall.RecentPercentDefects',
      decimal: 1,
      column: 'LowBodyRecentPercentDefects'
    }, 
    pw360TotalNumberDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.PW360.TotalNumberDefects',
      decimal: 1,
      column: 'pw360TotalNumberDefects'
    },
    pw360TotalPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.PW360.TotalPercentDefects',
      decimal: 1,
      column: 'pw360TotalPercentDefects'
    },
    pw360RecentPercentDefects: {
      node: 'ns=2;s=UA_Presco_OC2.presco.Lane2.PW360.RecentPercentDefects',
      decimal: 1,
      column: 'pw360RecentPercentDefects'
    }
  },
  flow_nozzle_filler2: {
    Mode_CSIOP: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_CSIOP',
      decimal: 'string',
      column: 'Mode_CSIOP'
    },
    Mode_Formalin: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Mode_Formalin',
      decimal: 'string',
      column: 'Mode_Formalin'
    },
    Mode_H2O2: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_H2O2',
      decimal: 'string',
      column: 'Mode_H2O2'
    },
    Mode_Nightime: {
      node:'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_Nightime',
      decimal: 'string',
      column: 'Mode_Nightime'
    },
    Mode_Production: {
      node: 'ns=2;s=PLC_FILLER2_IP1.Filiing2_Direct.Mode_Production',
      decimal: 'string',
      column: 'Mode_Production'
    },
    Nozzle_Flow_1: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_1',
      decimal: 1,
      column: 'Nozzle_Flow_1'
    },
    Nozzle_Flow_2: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_2',
      decimal: 1,
      column: 'Nozzle_Flow_2'
    },
    Nozzle_Flow_3: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_3',
      decimal: 1,
      column: 'Nozzle_Flow_3'
    },
    Nozzle_Flow_4: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_4',
      decimal: 1,
      column: 'Nozzle_Flow_4'
    },
    Nozzle_Flow_5: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_5',
      decimal: 1,
      column: 'Nozzle_Flow_5'
    },
    Nozzle_Flow_6: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_6',
      decimal: 1,
      column: 'Nozzle_Flow_6'
    },
    Nozzle_Flow_7: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_7',
      decimal: 1,
      column: 'Nozzle_Flow_7'
    },
    Nozzle_Flow_8: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_8',
      decimal: 1,
      column: 'Nozzle_Flow_8'
    },
    Nozzle_Flow_9: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_9',
      decimal: 1,
      column: 'Nozzle_Flow_9'
    },
    Nozzle_Flow_10: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_10',
      decimal: 1,
      column: 'Nozzle_Flow_10'
    },
    Nozzle_Flow_11: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_11',
      decimal: 1,
      column: 'Nozzle_Flow_11'
    },
    Nozzle_Flow_12: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_12',
      decimal: 1,
      column: 'Nozzle_Flow_12'
    },
    Nozzle_Flow_13: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_13',
      decimal: 1,
      column: 'Nozzle_Flow_13'
    },
    Nozzle_Flow_14: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_14',
      decimal: 1,
      column: 'Nozzle_Flow_14'
    },
    Nozzle_Flow_15: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_15',
      decimal: 1,
      column: 'Nozzle_Flow_15'
    },
    Nozzle_Flow_16: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_16',
      decimal: 1,
      column: 'Nozzle_Flow_16'
    },
    Nozzle_Flow_17: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_17',
      decimal: 1,
      column: 'Nozzle_Flow_17'
    },
    Nozzle_Flow_18: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_18',
      decimal: 1,
      column: 'Nozzle_Flow_18'
    },
    Nozzle_Flow_19: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_19',
      decimal: 1,
      column: 'Nozzle_Flow_19'
    },
    Nozzle_Flow_20: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_20',
      decimal: 1,
      column: 'Nozzle_Flow_20'
    },
    Nozzle_Flow_21: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_21',
      decimal: 1,
      column: 'Nozzle_Flow_21'
    },
    Nozzle_Flow_22: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_22',
      decimal: 1,
      column: 'Nozzle_Flow_22'
    },
    Nozzle_Flow_23: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_23',
      decimal: 1,
      column: 'Nozzle_Flow_23'
    },
    Nozzle_Flow_24: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_24',
      decimal: 1,
      column: 'Nozzle_Flow_24'
    },
    Nozzle_Flow_25: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_25',
      decimal: 1,
      column: 'Nozzle_Flow_25'
    },
    Nozzle_Flow_26: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_26',
      decimal: 1,
      column: 'Nozzle_Flow_26'
    },
    Nozzle_Flow_27: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_27',
      decimal: 1,
      column: 'Nozzle_Flow_27'
    },
    Nozzle_Flow_28: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_28',
      decimal: 1,
      column: 'Nozzle_Flow_28'
    },
    Nozzle_Flow_29: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_29',
      decimal: 1,
      column: 'Nozzle_Flow_29'
    },
    Nozzle_Flow_30: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_30',
      decimal: 1,
      column: 'Nozzle_Flow_30'
    },
    Nozzle_Flow_31: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_31',
      decimal: 1,
      column: 'Nozzle_Flow_31'
    },
    Nozzle_Flow_32: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_32',
      decimal: 1,
      column: 'Nozzle_Flow_32'
    },
    Nozzle_Flow_33: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_33',
      decimal: 1,
      column: 'Nozzle_Flow_33'
    },
    Nozzle_Flow_34: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_34',
      decimal: 1,
      column: 'Nozzle_Flow_34'
    },
    Nozzle_Flow_35: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_35',
      decimal: 1,
      column: 'Nozzle_Flow_35'
    },
    Nozzle_Flow_36: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_36',
      decimal: 1,
      column: 'Nozzle_Flow_36'
    },
    Nozzle_Flow_37: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_37',
      decimal: 1,
      column: 'Nozzle_Flow_37'
    },
    Nozzle_Flow_38: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_38',
      decimal: 1,
      column: 'Nozzle_Flow_38'
    },
    Nozzle_Flow_39: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_39',
      decimal: 1,
      column: 'Nozzle_Flow_39'
    },
    Nozzle_Flow_40: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_40',
      decimal: 1,
      column: 'Nozzle_Flow_40'
    },
    Nozzle_Flow_41: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_41',
      decimal: 1,
      column: 'Nozzle_Flow_41'
    },
    Nozzle_Flow_42: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_42',
      decimal: 1,
      column: 'Nozzle_Flow_42'
    },
    Nozzle_Flow_43: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_43',
      decimal: 1,
      column: 'Nozzle_Flow_43'
    },
    Nozzle_Flow_44: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_44',
      decimal: 1,
      column: 'Nozzle_Flow_44'
    },
    Nozzle_Flow_45: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_45',
      decimal: 1,
      column: 'Nozzle_Flow_45'
    },
    Nozzle_Flow_46: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_46',
      decimal: 1,
      column: 'Nozzle_Flow_46'
    },
    Nozzle_Flow_47: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_47',
      decimal: 1,
      column: 'Nozzle_Flow_47'
    },
    Nozzle_Flow_48: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_48',
      decimal: 1,
      column: 'Nozzle_Flow_48'
    },
    Nozzle_Flow_49: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_49',
      decimal: 1,
      column: 'Nozzle_Flow_49'
    },
    Nozzle_Flow_50: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_50',
      decimal: 1,
      column: 'Nozzle_Flow_50'
    },
    Nozzle_Flow_51: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_51',
      decimal: 1,
      column: 'Nozzle_Flow_51'
    },
    Nozzle_Flow_52: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_52',
      decimal: 1,
      column: 'Nozzle_Flow_52'
    },
    Nozzle_Flow_53: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_53',
      decimal: 1,
      column: 'Nozzle_Flow_53'
    },
    Nozzle_Flow_54: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_54',
      decimal: 1,
      column: 'Nozzle_Flow_54'
    },
    Nozzle_Flow_55: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_55',
      decimal: 1,
      column: 'Nozzle_Flow_55'
    },
    Nozzle_Flow_56: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_56',
      decimal: 1,
      column: 'Nozzle_Flow_56'
    },
    Nozzle_Flow_57: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_57',
      decimal: 1,
      column: 'Nozzle_Flow_57'
    },
    Nozzle_Flow_58: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_58',
      decimal: 1,
      column: 'Nozzle_Flow_58'
    },
    Nozzle_Flow_59: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_59',
      decimal: 1,
      column: 'Nozzle_Flow_59'
    },
    Nozzle_Flow_60: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.Nozzle_Flow_60',
      decimal: 1,
      column: 'Nozzle_Flow_60'
    },
    TIME_NOZZ_1: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_1',
      decimal: 1,
      column: 'TIME_NOZZ_1'
    },
    TIME_NOZZ_2: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_2',
      decimal: 1,
      column: 'TIME_NOZZ_2'
    },
    TIME_NOZZ_3: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_3',
      decimal: 1,
      column: 'TIME_NOZZ_3'
    },
    TIME_NOZZ_4: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_4',
      decimal: 1,
      column: 'TIME_NOZZ_4'
    },
    TIME_NOZZ_5: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_5',
      decimal: 1,
      column: 'TIME_NOZZ_5'
    },
    TIME_NOZZ_6: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_6',
      decimal: 1,
      column: 'TIME_NOZZ_6'
    },
    TIME_NOZZ_7: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_7',
      decimal: 1,
      column: 'TIME_NOZZ_7'
    },
    TIME_NOZZ_8: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_8',
      decimal: 1,
      column: 'TIME_NOZZ_8'
    },
    TIME_NOZZ_9: {
      node: 'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_9',
      decimal: 1,
      column: 'TIME_NOZZ_9'
    },
    TIME_NOZZ_10: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_10',
      decimal: 1,
      column: 'TIME_NOZZ_10'
    },
    TIME_NOZZ_11: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_11',
      decimal: 1,
      column: 'TIME_NOZZ_11'
    },
    TIME_NOZZ_12: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_12',
      decimal: 1,
      column: 'TIME_NOZZ_12'
    },
    TIME_NOZZ_13: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_13',
      decimal: 1,
      column: 'TIME_NOZZ_13'
    },
    TIME_NOZZ_14: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_14',
      decimal: 1,
      column: 'TIME_NOZZ_14'
    },
    TIME_NOZZ_15: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_15',
      decimal: 1,
      column: 'TIME_NOZZ_15'
    },
    TIME_NOZZ_16: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_16',
      decimal: 1,
      column: 'TIME_NOZZ_16'
    },
    TIME_NOZZ_17: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_17',
      decimal: 1,
      column: 'TIME_NOZZ_17'
    },
    TIME_NOZZ_18: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_18',
      decimal: 1,
      column: 'TIME_NOZZ_18'
    },
    TIME_NOZZ_19: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_19',
      decimal: 1,
      column: 'TIME_NOZZ_19'
    },
    TIME_NOZZ_20: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_20',
      decimal: 1,
      column: 'TIME_NOZZ_20'
    },
    TIME_NOZZ_21: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_21',
      decimal: 1,
      column: 'TIME_NOZZ_21'
    },
    TIME_NOZZ_22: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_22',
      decimal: 1,
      column: 'TIME_NOZZ_22'
    },
    TIME_NOZZ_23: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_23',
      decimal: 1,
      column: 'TIME_NOZZ_23'
    },
    TIME_NOZZ_24: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_24',
      decimal: 1,
      column: 'TIME_NOZZ_24'
    },
    TIME_NOZZ_25: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_25',
      decimal: 1,
      column: 'TIME_NOZZ_25'
    },
    TIME_NOZZ_26: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_26',
      decimal: 1,
      column: 'TIME_NOZZ_26'
    },
    TIME_NOZZ_27: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_27',
      decimal: 1,
      column: 'TIME_NOZZ_27'
    },
    TIME_NOZZ_28: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_28',
      decimal: 1,
      column: 'TIME_NOZZ_28'
    },
    TIME_NOZZ_29: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_29',
      decimal: 1,
      column: 'TIME_NOZZ_29'
    },
    TIME_NOZZ_30: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_30',
      decimal: 1,
      column: 'TIME_NOZZ_30'
    },
    TIME_NOZZ_31: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_31',
      decimal: 1,
      column: 'TIME_NOZZ_31'
    },
    TIME_NOZZ_32: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_32',
      decimal: 1,
      column: 'TIME_NOZZ_32'
    },
    TIME_NOZZ_33: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_33',
      decimal: 1,
      column: 'TIME_NOZZ_33'
    },
    TIME_NOZZ_34: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_34',
      decimal: 1,
      column: 'TIME_NOZZ_34'
    },
    TIME_NOZZ_35: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_35',
      decimal: 1,
      column: 'TIME_NOZZ_35'
    },
    TIME_NOZZ_36: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_36',
      decimal: 1,
      column: 'TIME_NOZZ_36'
    },
    TIME_NOZZ_37: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_37',
      decimal: 1,
      column: 'TIME_NOZZ_37'
    },
    TIME_NOZZ_38: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_38',
      decimal: 1,
      column: 'TIME_NOZZ_38'
    },
    TIME_NOZZ_39: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_39',
      decimal: 1,
      column: 'TIME_NOZZ_39'
    },
    TIME_NOZZ_40: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_40',
      decimal: 1,
      column: 'TIME_NOZZ_40'
    },
    TIME_NOZZ_41: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_41',
      decimal: 1,
      column: 'TIME_NOZZ_41'
    },
    TIME_NOZZ_42: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_42',
      decimal: 1,
      column: 'TIME_NOZZ_42'
    },
    TIME_NOZZ_43: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_43',
      decimal: 1,
      column: 'TIME_NOZZ_43'
    },
    TIME_NOZZ_44: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_44',
      decimal: 1,
      column: 'TIME_NOZZ_44'
    },
    TIME_NOZZ_45: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_45',
      decimal: 1,
      column: 'TIME_NOZZ_45'
    },
    TIME_NOZZ_46: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_46',
      decimal: 1,
      column: 'TIME_NOZZ_46'
    },
    TIME_NOZZ_47: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_47',
      decimal: 1,
      column: 'TIME_NOZZ_47'
    },
    TIME_NOZZ_48: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_48',
      decimal: 1,
      column: 'TIME_NOZZ_48'
    },
    TIME_NOZZ_49: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_49',
      decimal: 1,
      column: 'TIME_NOZZ_49'
    },
    TIME_NOZZ_50: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_50',
      decimal: 1,
      column: 'TIME_NOZZ_50'
    },
    TIME_NOZZ_51: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_51',
      decimal: 1,
      column: 'TIME_NOZZ_51'
    },
    TIME_NOZZ_52: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_52',
      decimal: 1,
      column: 'TIME_NOZZ_52'
    },
    TIME_NOZZ_53: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_53',
      decimal: 1,
      column: 'TIME_NOZZ_53'
    },
    TIME_NOZZ_54: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_54',
      decimal: 1,
      column: 'TIME_NOZZ_54'
    },
    TIME_NOZZ_55: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_55',
      decimal: 1,
      column: 'TIME_NOZZ_55'
    },
    TIME_NOZZ_56: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_56',
      decimal: 1,
      column: 'TIME_NOZZ_56'
    },
    TIME_NOZZ_57: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_57',
      decimal: 1,
      column: 'TIME_NOZZ_57'
    },
    TIME_NOZZ_58: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_58',
      decimal: 1,
      column: 'TIME_NOZZ_58'
    },
    TIME_NOZZ_59: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_59',
      decimal: 1,
      column: 'TIME_NOZZ_59'
    },
    TIME_NOZZ_60: {
      node:'ns=2;s=PLCMitsubishiOC2.Filler2.TIME_NOZZ_60',
      decimal: 1,
      column: 'TIME_NOZZ_60'
  }
  },
  cttn_caser2: {
    CNT_Box_Caser: {
      node:'ns=2;s=PLCMitsubishiOC2.Caser.CNT_Box_Caser',
      decimal: 1,
      column: 'CNT_Box_Caser'
    },
    CNT_back_both_sides_flap: {
      node:'ns=2;s=PLCMitsubishiOC2.Caser.GKM_CNT_back both sides flap',
      decimal: 1,
      column: 'CNT_back_both_sides_flap'
    },
    CNT_left_sides_flap: {
      node:'ns=2;s=PLCMitsubishiOC2.Caser.GKM_CNT_left side flap',
      decimal: 1,
      column: 'CNT_left_sides_flap'
    },
    CNT_right_sides_flap: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.GKM_CNT_right side flap',
      decimal: 1,
      column: 'CNT_right_sides_flap'
    },
    CNT_top_sides_flap: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.GKM_CNT_top flap',
      decimal: 1,
      column: 'CNT_top_sides_flap'
    },
    Total_waktu_back_both_side_flap: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.GKM_Total Waktu_Back both sides flap',
      decimal: 1,
      column: 'Total_waktu_back_both_side_flap'
    },
    Total_waktu_top_flap: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.GKM_Total Waktu_Top flap',
      decimal: 1,
      column: 'Total_waktu_top_flap'
    },
    Total_waktu_left_side_flap: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.GKM_Total Waktu_left side flap',
      decimal: 1,
      column: 'Total_waktu_left_side_flap'
    },
    Total_waktu_right_side_flap: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.GKM_Total Waktu_right side flap',
      decimal: 1,
      column: 'Total_waktu_right_side_flap'
    },
    status_caser: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.Status Caser',
      decimal: 'string',
      column: 'status_caser'
    },
    status_CDL: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.Status_CDL',
      decimal: 'string',
      column: 'status_CDL'
    },
    counting_NG_weight_checker: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.counting NG weight checker',
      decimal: 1,
      column: 'counting_NG_weight_checker'
    },
    counting_sensor_confirm_reject_box: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.counting Sensor confirm reject box',
      decimal: 1,
      column: 'counting_sensor_confirm_reject_box'
    },
    receipt_350ml: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.receipt 350ml',
      decimal: 'string',
      column: 'receipt_350ml'
    },
    receipt_500ml: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.receipt 500ml',
      decimal: 'string',
      column: 'receipt_500ml'
    },
    receipt_900ml: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.receipt 900ml',
      decimal: 'string',
      column: 'receipt_900ml'
    },
    DelayTIM_01SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_01SP',
      decimal: 1,
      column: 'DelayTIM_01SP'
    },
    DelayTIM_02SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_02SP',
      decimal: 1,
      column: 'DelayTIM_02SP'
    },
    DelayTIM_03SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_03SP',
      decimal: 1,
      column: 'DelayTIM_03SP'
    },
    DelayTIM_04SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_04SP',
      decimal: 1,
      column: 'DelayTIM_04SP'
    },
    DelayTIM_05SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_05SP',
      decimal: 1,
      column: 'DelayTIM_05SP'
    },
    DelayTIM_06SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_06SP',
      decimal: 1,
      column: 'DelayTIM_06SP'
    },
    DelayTIM_07SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_07SP',
      decimal: 1,
      column: 'DelayTIM_07SP'
    },
    DelayTIM_08SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_08SP',
      decimal: 1,
      column: 'DelayTIM_08SP'
    },
    DelayTIM_09SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_09SP',
      decimal: 1,
      column: 'DelayTIM_09SP'
    },
    DelayTIM_10SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_10SP',
      decimal: 1,
      column: 'DelayTIM_10SP'
    },
    DelayTIM_11SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_11SP',
      decimal: 1,
      column: 'DelayTIM_11SP'
    },
    DelayTIM_12SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.DelayTIM_12SP',
      decimal: 1,
      column: 'DelayTIM_12SP'
    },  
    Ycoord_01SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_01SP',
      decimal: 1,
      column: 'Ycoord_01SP'
    },
    Ycoord_02SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_02SP',
      decimal: 1,
      column: 'Ycoord_02SP'
    },
    Ycoord_03SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_03SP',
      decimal: 1,
      column: 'Ycoord_03SP'
    },
    Ycoord_04SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_04SP',
      decimal: 1,
      column: 'Ycoord_04SP'
    },
    Ycoord_05SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_05SP',
      decimal: 1,
      column: 'Ycoord_05SP'
    },
    Ycoord_06SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_06SP',
      decimal: 1,
      column: 'Ycoord_06SP'
    },
    Ycoord_07SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_07SP',
      decimal: 1,
      column: 'Ycoord_07SP'
    },
    Ycoord_08SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_08SP',
      decimal: 1,
      column: 'Ycoord_08SP'
    },
    Ycoord_09SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_09SP',
      decimal: 1,
      column: 'Ycoord_09SP'
    },
    Ycoord_10SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_10SP',
      decimal: 1,
      column: 'Ycoord_10SP'
    },
    Ycoord_11SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_11SP',
      decimal: 1,
      column: 'Ycoord_11SP'
    },
    Ycoord_12SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.Ycoord_12SP',
      decimal: 1,
      column: 'Ycoord_12SP'
    },
    EXPANSION_DECEL_SP: {
      node:'ns=2;s=PLCMitsubishiOC2.Divider.EXPANSION_DECEL_SP',
      decimal: 1,
      column: 'EXPANSION_DECEL_SP'
    },
    EXPANSION_ACC_SP: {
      node:'ns=2;s=PLCMitsubishiOC2.Divider.EXPANSION_ACC_SP',
      decimal: 1,
      column: 'EXPANSION_ACC_SP'
    },
    DISTRIBUTION_NUMBER_SP: {
      node:'ns=2;s=PLCMitsubishiOC2.Divider.DISTRIBUTION_NUMBER_SP',
      decimal: 1,
      column: 'DISTRIBUTION_NUMBER_SP'
    },
    RET_ACC_TIME_SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.RET_ACC_TIME_SP',
      decimal: 1,
      column: 'RET_ACC_TIME_SP'
    },
    RET_DECEL_TIME_SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.RET_DECEL_TIME_SP',
      decimal: 1,
      column: 'RET_DECEL_TIME_SP'
    },
    RETURNSPEED_SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.RETURNSPEED_SP',
      decimal: 1,
      column: 'RETURNSPEED_SP'
    },
    SWING_AXIS_ACC_SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.SWING_AXIS_ACC_SP',
      decimal: 1,
      column: 'SWING_AXIS_ACC_SP'
    },
    SWING_AXIS_DECEL_SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.SWING_AXIS_DECEL_SP',
      decimal: 1,
      column: 'SWING_AXIS_DECEL_SP'
    },
    NODP_SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.NODP_SP',
      decimal: 1,
      column: 'NODP_SP'
    },
    SAB_SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.SAB_SP',
      decimal: 1,
      column: 'SAB_SP'
    },
    CV_SPEED_SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.CV_SPEED_SP',
      decimal: 1,
      column: 'CV_SPEED_SP'
    },
    TIME_TSF_SP: {
      node: 'ns=2;s=PLCMitsubishiOC2.Divider.TIME_TSF_SP',
      decimal: 1,
      column: 'TIME_TSF_SP'
    },
    UP_LIMIT_OF_CLAMPS: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.UP_LIMIT_OF_CLAMPS',
      decimal: 1,
      column: 'UP_LIMIT_OF_CLAMPS'
    },
    delay_separation: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.DELAY_SEPARATION',
      decimal: 1,
      column: 'delay_separation'
    },
    EQ_Ability: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.EX ABILITY',
      decimal: 1,
      column: 'EQ_Ability'
    },
    EQ_Ability_30_box: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.EQ_ABILITY_30_BOX',
      decimal: 1,
      column: 'EQ_Ability_30_box'
    },
    EQ_Ability_32_box: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.EQ_ABILITY_32_BOX',
      decimal: 1,
      column: 'EQ_Ability_32_box'
    },
    Wait_Axis_Monitor: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.WAIT_AXIS_MONITOR',
      decimal: 1,
      column: 'Wait_Axis_Monitor'
    },
    Wait_Axis_start: {
      node: 'ns=2;s=PLCMitsubishiOC2.Caser.WAIT_AXIS_START',
      decimal: 1,
      column: 'Wait_Axis_start'
    },
    present_number: {
      node:'ns=2;s=PLCMitsubishiOC2.Divider.PRESENT_NUMBER',
      decimal: 1,
      column: 'present_number'
    },
    volume_prod: {
      node:'ns=2;s=PLCMitsubishiOC2.Divider.VOLUME_PRODUCTION',
      decimal: 1,
      column: 'volume_prod'
    },
    eff_divider: {
      node:'ns=2;s=PLCMitsubishiOC2.Divider.EFF_Divider',
      decimal: 1,
      column: 'eff_divider'
    },
    eff_caser: {
      node:'ns=2;s=PLCMitsubishiOC2.Caser.EFF_Caser',
      decimal: 1,
      column: 'eff_caser'
    },
    palletizer_count_box: {
      node:'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Count_BOX',
      decimal: 1,
      column: 'palletizer_count_box'
    },
    palletizer_count_pallet_new: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Count_Pallet_New',
      decimal: 1,
      column: 'palletizer_count_pallet_new'
    },
    eff_pallet: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.EFF_Pallet',
      decimal: 1,
      column: 'eff_pallet'
    },
    modeltype_1: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_1',
      decimal: 1,
      column: 'modeltype_1'
    },
    modeltype_2: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_2',
      decimal: 1,
      column: 'modeltype_2'
    },
    modeltype_3: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_3',
      decimal: 1,
      column: 'modeltype_3'
    },
    modeltype_4: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_4',
      decimal: 1,
      column: 'modeltype_4'
    },
    modeltype_5: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_5',
      decimal: 1,
      column: 'modeltype_5'
    },
    modeltype_6: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_6',
      decimal: 1,
      column: 'modeltype_6'
    },
    modeltype_7: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_7',
      decimal: 1,
      column: 'modeltype_7'
    },
    modeltype_8: {
      node:'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_8',
      decimal: 1,
      column: 'modeltype_8'
    },
    modeltype_9: {
      node:'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_9',
      decimal: 1,
      column: 'modeltype_9'
    },
    modeltype_10: {
      node:'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.Modeltype_10',
      decimal: 1,
      column: 'modeltype_10'
    },
    ability: {
      node:'ns=2;s=PLCMitsubishiOC2.Caser.ABILITY',
      decimal: 1,
      column: 'ability'
    },
    Palletizer_NomorType: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.NomorType',
      decimal:1,
      column: 'Palletizer_NomorType'
    },
    Palletizer_TypeDigunakan: {
      node:'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.TypeDigunakan',
      decimal: 1,
      column: 'Palletizer_TypeDigunakan'
    },
    Palletizer_TypeNomor: {
      node: 'ns=2;s=PLCMitsubishiOC2.PalletizerOC2.TypeNomor',
      decimal:1,
      column: 'Palletizer_TypeNomor'
    }
  },
  piovan2: {
    Cooling_coil_water_inlet: {
      node: 'ns=2;s=ModbusTCP.Piovan2.Cooling_coil_water_inlet',
      decimal: 1,
      column: 'Cooling_coil_water_inlet'
    },
    DewPoint: {
      node: 'ns=2;s=ModbusTCP.Piovan2.DewPoint',
      decimal: 1,
      column: 'DewPoint'
    },
    L_tower_inlet_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.L_tower_inlet_temp',
      decimal: 1,
      column: 'L_tower_inlet_temp'
    },
    L_tower_outlet_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.L_tower_outlet_temp',
      decimal: 1,
      column: 'L_tower_outlet_temp'
    },
    POD: {
      node: 'ns=2;s=ModbusTCP.Piovan2.POD',
      decimal: 1,
      column: 'POD'
    },
    Process_blower_1: {
      node: 'ns=2;s=ModbusTCP.Piovan2.Process_blower_1',
      decimal: 1,
      column: 'Process_blower_1',
    },
    Process_blower_2: {
      node: 'ns=2;s=ModbusTCP.Piovan2.Process_blower_2',
      decimal: 1,
      column: 'Process_blower_2'
    },
    R_tower_inlet_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.R_tower_inlet_temp',
      decimal: 1,
      column: 'R_tower_inlet_temp',
    },
    R_tower_outlet_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.R_tower_outlet_temp',
      decimal: 1,
      column: 'R_tower_outlet_temp',
    },
    airflow: {
      node: 'ns=2;s=ModbusTCP.Piovan2.airflow',
      decimal: 1,
      column: 'airflow',
    },
    analog0: {
      node: 'ns=2;s=ModbusTCP.Piovan2.analog0',
      decimal: 1,
      column: 'analog0',
    },
    cone_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.cone_temp',
      decimal: 1,
      column: 'cone_temp',
    },
    cylinder_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.cylinder_temp',
      decimal: 1,
      column: 'cylinder_temp',
    },
    heating_power: {
      node: 'ns=2;s=ModbusTCP.Piovan2.heating_power',
      decimal: 1,
      column: 'heating_power',
    },
    hopper_material_lvl: {
      node: 'ns=2;s=ModbusTCP.Piovan2.hopper_material_lvl',
      decimal: 1,
      column: 'hopper_material_lvl',
    },
    hopper_material_weight: {
      node: 'ns=2;s=ModbusTCP.Piovan2.hopper_material_weight',
      decimal: 1,
      column: 'hopper_material_weight'
    },
    l_inlet_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.l_inlet_temp',
      decimal: 1,
      column: 'l_inlet_temp',
    },
    material_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.material_temp',
      decimal: 1,
      column: 'material_temp',
    },
    process_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.process_temp',
      decimal: 1,
      column: 'process_temp',
    },
    regeneration_cyce_done: {
      node: 'ns=2;s=ModbusTCP.Piovan2.regeneration_cyce_done',
      decimal: 1,
      column: 'regeneration_cyce_done',
    },
    regeneration_phase: {
      node: 'ns=2;s=ModbusTCP.Piovan2.regeneration_phase',
      decimal: 1,
      column: 'regeneration_phase',
    },
    return_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.return_temp',
      decimal: 1,
      column: 'return_temp',
    },
    safety_process_temp: {
      node: 'ns=2;s=ModbusTCP.Piovan2.safety_process_temp',
      decimal: 1,
      column: 'safety_process_temp',
    },
    Receiver_1_on_off: {
      node: 'ns=2;s=ModbusTCP.Piovan2.Receiver 1 on_off',
      decimal: "string",
      column: 'Receiver_1_on_off',
    },
    Receiver_1_suction_time: {
      node: 'ns=2;s=ModbusTCP.Piovan2.Receiver 1 suction time',
      decimal: 1,
      column: 'Receiver_1_suction_time',
    },
    silo_oc2: {
      node: 'ns=2;s=Modbuss-Energy1.silo_oc2_152_153.kg_silo',
      decimal: 1,
      column: 'silo_oc2',
    }
  },
  kanesho_oc2: {
    Injeksi_extend_mode: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.Injeksi_extend_mode',
      decimal: 1,
      column: 'Injeksi_extend_mode'
    },
    status_kanesho: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.status_Kanesho',
      decimal: 1,
      column: 'Status_kanesho'
    },    
    counter_operation_blower_change: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.counter_operation_blower_change',
      decimal: 1,
      column: 'counter_operation_blower_change'
    },
    counter_operation_elev_entrance_hopper: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.counter_operation_elev_entrance_hopper',
      decimal: 1,
      column: 'counter_operation_elev_entrance_hopper'
    },
    counter_operation_elev_reg_side_hopper: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.counter_operation_elev_reg_side_hopper',
      decimal: 1,
      column: 'counter_operation_elev_reg_side_hopper'
    },
    timer_x246_blower_change_open: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x246_blower_change_open',
      decimal: 1,
      column: 'timer_x246_blower_change_open'
    },
    timer_x247_blower_change_open: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x247_blower_change_open',
      decimal: 1,
      column: 'timer_x247_blower_change_open'
    },
    timer_x281_elev_entrance_hoper_open: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x281_elev_entrance_hoper_open',
      decimal: 1,
      column: 'timer_x281_elev_entrance_hoper_open'
    },
    timer_x282_elev_entrance_hoper_close: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x282_elev_entrance_hoper_close',
      decimal: 1,
      column: 'timer_x282_elev_entrance_hoper_close'
    },
    timer_x288_elev_reg_side_open: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x288_elev_reg_side_open',
      decimal: 1,
      column: 'timer_x288_elev_reg_side_open'
    },
    timer_x289_elev_reg_hopper_close: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x289_elev_reg_hopper_close',
      decimal: 1,
      column: 'timer_x289_elev_reg_hopper_close'
    },
    timer_x28a_elev_reg_side_open: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x28a_elev_reg_side_open',
      decimal: 1,
      column: 'timer_x28a_elev_reg_side_open'
    },
    timer_x28b_elev_reg_hopper_close: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x28b_elev_reg_hopper_close',
      decimal: 1,
      column: 'timer_x28b_elev_reg_hopper_close'
    },
    timer_x28c_elev_accum_side_open: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x28c_elev_accum_side_open',
      decimal: 1,
      column: 'timer_x28c_elev_accum_side_open'
    },
    timer_x28d_elev_accum_hopper_close: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x28d_elev_accum_hopper_close',
      decimal: 1,
      column: 'timer_x28d_elev_accum_hopper_close'
    },
    timer_x28e_elev_accum_side_open: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x28e_elev_accum_side_open',
      decimal: 1,
      column: 'timer_x28e_elev_accum_side_open'
    },
    timer_x28f_elev_accum_hopper_close: {
      node:'ns=2;s=PLCMitsubishiOC2.Kanesho.timer_x28f_elev_accum_hopper_close',
      decimal: 1,
      column: 'timer_x28f_elev_accum_hopper_close'
    }

  }
};